----------------------------
Windows Desktop Notes ReadMe
----------------------------
Copyright 2007 by Chris Done
Last updated: 01:15 06/05/2007

How to use
----------

    Downloading & Installing
    ------------------------
		
    Download the latest .zip archive. Extract wdn.exe from the .zip file.

    I suggest copying it to C:\WINDOWS for easy access from cmd and Run
		(I tend to hit the Windows + R shortcut for Run and type the program
		name to open it; in this case wdn).

    Now you just have to open it and it will pop up on your desktop. Be
		sure
		to move your icons out of the way (by default, it opens at the
		top-left of dimensions around 500x500)!
		
		
    Moving
    ------
    Simply click the area where text is displayed, in the case of first
		opening, where it says 'Hello', and drag. A border outline around the
		window will be shown so that you can better see it.
		
		
    Resizing
    --------
    This feature isn't implemented yet.


    Entering Text
    ------------
    Double-click the area where text is displayed. An editing textbox will
		appear in the exact place as the text displayed. When you have finished
		editing the text, click anywhere else on the desktop or another window;
		so that the textbox loses focus. Editing mode will finish and it will
		return to normal display mode. The notes will also be saved to a file
		notes.txt
		
		
    Settings
    --------
    This feature isn't implemented yet. What you can do, if you want to
		change the font and text size, is create a wdn.ini file and put in
		something like the following:

        [text]
        font=Arial
        size=12

    And re-open Windows Desktop Notes. 



TODO
----

    Things that need to be done/things I want to do:

        * Add unicode support for text display.
        * Add a resizing feature.
        * Saves last position and dimensions.
        * Create a settings dialog with: option to change font, option to
				  change text shadow; option to change font colour.
        * Add a right-click menu.

Source
------

    Grab the source from the SVN:

    svn co https://slsk.svn.sourceforge.net/svnroot/slsk/wdm slsk

    I tend to commit to SVN whenever I make a bugfix or add a new feature.
