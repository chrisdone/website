/*

Copyright (c) 2007, Chris Done

All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

    * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in
    the documentation and/or other materials provided with the distribution.
    * Neither the name of the Windows Desktop Notes nor the names of its
    contributors may be used to endorse or promote products derived
    from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "config.h"
#include <windows.h>

#define WDN_CLASSNAME "WindowsDesktopNotes"

LRESULT CALLBACK main_procedure(HWND, UINT, WPARAM, LPARAM);

BOOL register_window(HINSTANCE the_instance);

int WINAPI WinMain(HINSTANCE instance_this,
                   HINSTANCE instance_prev,
                   LPSTR arguments,
                   int show)
{
    int result = EXIT_SUCCESS;
    LPTSTR error = NULL;

    if (register_window(instance_this) != 0)
    {
        HWND desktop_handle;
        desktop_handle = FindWindowEx(NULL, NULL, TEXT("Progman"), NULL);
        if (desktop_handle != NULL)
        {
            HWND hwnd;

            hwnd = CreateWindow(TEXT(WDN_CLASSNAME), TEXT(WDN_CLASSNAME), WS_POPUP,
                                20, 20, 600, 600,
                                NULL, 0, instance_this, NULL);
            if (hwnd != NULL)
            {
                MSG messages;

                SetParent(hwnd, desktop_handle);
                ShowWindow(hwnd, SW_SHOW);
                while (GetMessage (&messages, NULL, 0, 0))
                {
                    TranslateMessage(&messages);
                    DispatchMessage(&messages);
                }
            }
            else { error = TEXT("Unable to create window."); result = EXIT_FAILURE; }
        }
        else { error = TEXT("Unable to find desktop window."); result = EXIT_FAILURE; }
    }
    else { error = TEXT("Unable to find register window class."); result = EXIT_FAILURE; }

    if (error != NULL)
    {
        MessageBox(NULL, error, TEXT(WDN_CLASSNAME), MB_ICONERROR);
    }

    return result;
}
