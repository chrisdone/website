/*

Copyright (c) 2007, Chris Done

All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

    * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in
    the documentation and/or other materials provided with the distribution.
    * Neither the name of the Windows Desktop Notes nor the names of its
    contributors may be used to endorse or promote products derived
    from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "config.h"
#include "events.h"
#include "painting.h"
#include "window.h"
#include "fileio.h"

#define UNICODE
#include <windows.h>

EVENT_CALLBACK(on_create);
EVENT_CALLBACK(on_paint);
EVENT_CALLBACK(on_erasebackground);
EVENT_CALLBACK(on_lbuttondown);
EVENT_CALLBACK(on_rbuttondown);
EVENT_CALLBACK(on_rbuttonup);
EVENT_CALLBACK(on_mousemove);
EVENT_CALLBACK(on_destroy);
EVENT_CALLBACK(on_lbuttondoubleclick);
EVENT_CALLBACK(on_size);
EVENT_CALLBACK(on_keydown);
EVENT_CALLBACK(on_command);
EVENT_CALLBACK(on_edit_change);
EVENT_CALLBACK(on_edit_lostfocus);

LRESULT CALLBACK main_procedure(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
            HANDLE_EVENT(WM_CREATE, on_create);
            HANDLE_EVENT(WM_PAINT, on_paint);
            HANDLE_EVENT(WM_ERASEBKGND, on_erasebackground);
            HANDLE_EVENT(WM_LBUTTONDOWN, on_lbuttondown);
            HANDLE_EVENT(WM_RBUTTONDOWN, on_rbuttondown);
            HANDLE_EVENT(WM_RBUTTONUP, on_rbuttonup);
            HANDLE_EVENT(WM_MOUSEMOVE, on_mousemove);
            HANDLE_EVENT(WM_DESTROY, on_destroy);
            HANDLE_EVENT(WM_LBUTTONDBLCLK, on_lbuttondoubleclick);
            HANDLE_EVENT(WM_SIZE, on_size);
            HANDLE_EVENT(WM_KEYDOWN, on_keydown);
            HANDLE_EVENT(WM_COMMAND, on_command);
        default:
            return DefWindowProc (hwnd, message, wParam, lParam);
    }

    return 0;
}

EVENT_CALLBACK(on_create)
{
    window_data *window;
    LONG font_size;
    HDC hdc;
    LPTSTR text;
    LONG result;
    TCHAR font[MAX_FONT_LEN];
    TCHAR size[10];
    CHAR strTmp[21];
    INT default_font_size = DEFAULT_FONT_SIZE;
    TCHAR default_font_size_str[10];
    TCHAR shade[6];
    wsprintf(default_font_size_str, TEXT("%d"), DEFAULT_FONT_SIZE);


    /* Create structure for storing info about the window. */
    window = malloc(sizeof *window);
    window_data_init(window);
    SetWindowLongPtr(hwnd, GWL_USERDATA, (LONG_PTR)window);
    /* Done doing window struct stuff. */

    result = GetPrivateProfileString(TEXT("text"), TEXT("font"), TEXT(DEFAULT_FONT_FACE), font, MAX_FONT_LEN, TEXT(INI_PATH));
    result = GetPrivateProfileString(TEXT("text"), TEXT("size"), default_font_size_str, size, MAX_FONT_LEN, TEXT(INI_PATH));
    result = GetPrivateProfileString(TEXT("text"), TEXT("shade"), shade, size, 6, TEXT(INI_PATH));

    if (!wcscmp(shade, TEXT("dark")))
    {
        window->shade = DARK;
    }
    else if (!wcscmp(shade, TEXT("light")))
    {
        window->shade = LIGHT;
    }

    wcstombs(strTmp, size, sizeof(strTmp));
    MessageBox(NULL, font, TEXT("font size:"), 0);
    default_font_size = atoi(strTmp);

    if (default_font_size <= 15 && default_font_size >= 8)
    {

    }

    /* Create a font. */
    hdc = GetDC(hwnd);
    font_size = MulDiv(default_font_size, GetDeviceCaps(hdc, LOGPIXELSY), 72);
    window->font = CreateFont(font_size, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, font);
    ReleaseDC(hwnd, hdc);

    if (read_from_file(NOTES_FILENAME, &window->text, &window->textlen) == TRUE)
    {
        text = window->text;
    }
    else
    text = TEXT(NO_NOTES_MESSAGE);


    /* Create an edit control. */
    window->edit = CreateWindowEx(WS_EX_TRANSPARENT, TEXT("EDIT"), text, WS_CHILD + ES_MULTILINE,
                                  2, 2, 50, 15, hwnd, NULL, (HINSTANCE)GetWindowLongPtr(hwnd, GWL_HINSTANCE), NULL);
    /* Set the control font. */
    SendMessage(window->edit, WM_SETFONT, (WPARAM)window->font, TRUE);

    return 0;
}

EVENT_CALLBACK(on_paint)
{
    window_data *window;
    HDC hdc;
    PAINTSTRUCT ps;
    RECT text_position;
    RECT rect;
    HFONT old_font;
    LPTSTR text;
    int len;
    HDC memory_dc;
    HDC the_dc;
    HANDLE old_objects;
    HBITMAP memory_bitmap;
    COLORREF shadow = RGB(255, 255, 255);
    COLORREF forecolour = RGB(0, 0, 0);

    GetClientRect(hwnd, &rect);

    window = (window_data *)GetWindowLongPtr(hwnd, GWL_USERDATA);

    hdc = BeginPaint(hwnd, &ps);

    the_dc = hdc;

    if (window->editing != TRUE)
    {
        SetBkMode(the_dc, TRANSPARENT);

        /* Paints the desktop background. */
        if (PaintDesktop(the_dc) == 0)
        {
            PostQuitMessage(0);
        }

        text_position.top = 2;
        text_position.left = 2;
        text_position.right= rect.right - 2 + 1;
        text_position.bottom = rect.bottom - 2 + 1;

        /* Draw notes. */
        old_font = SelectObject(the_dc, window->font);
        if (window->text == NULL)
        {
            text = TEXT(NO_NOTES_MESSAGE);
            len = NO_NOTES_LEN;
        }
        else
        {
            text = window->text;
            len = window->textlen;
        }

        /* Draw "shadow" text. */
        /* Needs DT_EDITCONTROL so it doesn't draw new line squares. */

        SetTextColor(the_dc, shadow);

        DrawText(the_dc, text, len, &text_position, DT_TOP | DT_LEFT | DT_WORDBREAK | DT_EDITCONTROL);

        text_position.top--;
        text_position.bottom--;
        text_position.left--;
        text_position.right--;

        SetTextColor(the_dc, forecolour);
        DrawText(the_dc, text, len, &text_position, DT_TOP | DT_LEFT | DT_WORDBREAK | DT_EDITCONTROL);

        SelectObject(the_dc, old_font);

        if (window->moving == TRUE)
        {
            HPEN pen, old_pen;
            pen = CreatePen(PS_SOLID, 3, RGB(100, 100, 100));
            old_pen = SelectObject(the_dc, pen);
            draw_border(the_dc, &rect);
            SelectObject(the_dc, old_pen);
        }
    }
    else
    {
        HPEN pen, old_pen;
        pen = CreatePen(PS_SOLID, 3, RGB(100, 100, 100));
        old_pen = SelectObject(the_dc, pen);
        draw_border(the_dc, &rect);
        SelectObject(the_dc, old_pen);
    }

    EndPaint(hwnd, &ps);

    return 0;
}

EVENT_CALLBACK(on_erasebackground)
{
    /* Stops flickering. */
    return TRUE;
}

EVENT_CALLBACK(on_lbuttondown)
{
    window_data *window;

    window = (window_data *)GetWindowLongPtr(hwnd, GWL_USERDATA);

    window->moving = TRUE;
    InvalidateRect(hwnd, NULL, FALSE);

    /* The window can be dragged. */
    return SendMessage(hwnd, WM_NCLBUTTONDOWN, HTCAPTION, 0);
}

EVENT_CALLBACK(on_rbuttondown)
{
    HWND desktop;

    desktop = FindWindowEx(NULL, NULL, TEXT("Progman"), NULL);
    if (desktop != NULL)
    {
        return SendMessage(desktop, WM_RBUTTONDOWN, lParam, wParam);
    }
}

EVENT_CALLBACK(on_rbuttonup)
{
    HWND desktop;

    desktop = FindWindowEx(NULL, NULL, TEXT("Progman"), NULL);
    if (desktop != NULL)
    {
        return SendMessage(desktop, WM_RBUTTONUP, lParam, wParam);
    }
}

EVENT_CALLBACK(on_lbuttondoubleclick)
{
    window_data *window;

    window = (window_data *)GetWindowLongPtr(hwnd, GWL_USERDATA);
    ShowWindow(window->edit, SW_SHOW);
    SetFocus(window->edit);
    SetWindowLong(hwnd, GWL_STYLE, GetWindowLong(hwnd, GWL_STYLE));
    RECT window_size;
    GetWindowRect(hwnd, &window_size);
    window->editing = TRUE;
    InvalidateRect(hwnd, NULL, FALSE);

    return 0;
}

EVENT_CALLBACK(on_mousemove)
{
    window_data *window;

    window = (window_data *)GetWindowLongPtr(hwnd, GWL_USERDATA);
    if (window->moving == TRUE)
    {
        window->moving = FALSE;
        InvalidateRect(hwnd, NULL, FALSE);
    }

    return 0;
}

EVENT_CALLBACK(on_destroy)
{
    window_data *window;

    window = (window_data *)GetWindowLongPtr(hwnd, GWL_USERDATA);

    save_to_file(NOTES_FILENAME, window->text, window->textlen);

    PostQuitMessage(0);

    return 0;
}

EVENT_CALLBACK(on_keydown)
{
    if (wParam == VK_ESCAPE)
    {
        window_data *window;

        window = (window_data *)GetWindowLongPtr(hwnd, GWL_USERDATA);
        ShowWindow(window->edit, SW_HIDE);
    }

    return 0;
}

EVENT_CALLBACK(on_size)
{
    int x, y;
    int xn, yn; /* Subtract these. */
    window_data *window;

    window = (window_data *)GetWindowLongPtr(hwnd, GWL_USERDATA);

    RECT window_size;
    GetClientRect(hwnd, &window_size);
    if (!window->editing)
    {x = 2; y = 2;yn = 4;xn=4;}
    else
    {x = 0; y =0;xn=0;yn=0;}
    SetWindowPos(window->edit, NULL, x, y, window_size.right -xn, window_size.bottom-yn, 0);

    return 0;
}

EVENT_CALLBACK(on_command)
{
    int event;

    event = HIWORD(wParam);
    switch (event)
    {
            HANDLE_EVENT(EN_CHANGE, on_edit_change);
            HANDLE_EVENT(EN_KILLFOCUS, on_edit_lostfocus);
        default:
            return DefWindowProc(hwnd, WM_COMMAND, wParam, lParam);
    }

    return 0;
}

EVENT_CALLBACK(on_edit_change)
{
    window_data *window;

    window = (window_data *)GetWindowLongPtr(hwnd, GWL_USERDATA);



    return 0;
}

EVENT_CALLBACK(on_edit_lostfocus)
{
    window_data *window;
    int length;

    window = (window_data *)GetWindowLongPtr(hwnd, GWL_USERDATA);

    InvalidateRect(hwnd, NULL, FALSE);
    /* Hide the edit control. */
    ShowWindow(window->edit, SW_HIDE);

    /* Save its contents to a string to be painted later. */
    if (window->text != NULL) free(window->text);
    length = GetWindowTextLength(window->edit);
    window->text = malloc((length * 2) + 1);
    GetWindowText(window->edit, window->text, length + 1);
    window->textlen = length;

    window->editing = FALSE;

    save_to_file(NOTES_FILENAME, window->text, window->textlen);

    SetWindowLong(hwnd, GWL_STYLE, GetWindowLong(hwnd, GWL_STYLE));

    return 0;
}
