/*-------------------------------- message.c ----------------------------------*/

#include <stdlib.h>
#include <string.h>
#include <limits.h>

#include "message.h"

void intBytesToChar (unsigned char *charTo, unsigned int num)
{
    charTo[3] = (num >> (CHAR_BIT * 3));
    charTo[2] = ((num << (CHAR_BIT * 1)) >> (CHAR_BIT * 3));
    charTo[1] = ((num << (CHAR_BIT * 2)) >> (CHAR_BIT * 3));
    charTo[0] = ((num << (CHAR_BIT * 3)) >> (CHAR_BIT * 3));
}

int intFromChars (unsigned char *charFrom)
{
    unsigned int newInteger;

    newInteger = newInteger & 0;

    newInteger = (newInteger + charFrom[3]) << (CHAR_BIT * 3);
    newInteger = (newInteger + charFrom[2]) << (CHAR_BIT * 2);
    newInteger = (newInteger + charFrom[1]) << (CHAR_BIT);
    newInteger = (newInteger + charFrom[0]);

    return newInteger;
}

struct data *getMessage (struct data *buffer, int bytes, int messageLength)
{
    struct data *newMessageObject = NULL;
    char *newBufferData;

    /* Copy message data to new data object: */
    newMessageObject = newData (buffer->data, messageLength);

    /* If there is more data left on the buffer, then put it to the front. */
    if ((bytes - messageLength) > 0)
    {
        newBufferData = malloc (bytes - messageLength);
        if (newBufferData == NULL)
            abort();
        memcpy (newBufferData, (buffer->data + messageLength), (bytes - messageLength));

        free (buffer->data);
        buffer->data = newBufferData;
        buffer->length = bytes - messageLength;
    }

    return newMessageObject;
}

struct data *parseData (struct data *buffer, char *data, int length)
{
    static int      messageLength = 0;
    static int      realLength = 0;
    static int      bytes = 0;
    struct data *   messageData = NULL;
    struct data *   tempData;
    char *temp;
    int bufflen;

    /* See if we need to allocate more memory: */
    if ((buffer->length - bytes) < length)
        /* Allocate at least ALLOCATE_LENGTH bytes per time to reduce the amount of re-allocation: */
        buffer->length += ALLOCATE_LENGTH * ((length / ALLOCATE_LENGTH) + 1);

    /* Allocate enough bytes: */
    if (buffer->data == NULL)
    {
        buffer->data = malloc (buffer->length);
        if (buffer->data == NULL)
            abort();
    }
    else
    {
        /* Should only happen every ALLOCATE_LENGTH bytes. */
        buffer->data = realloc (buffer->data, buffer->length);
        if (buffer->data == NULL)
            abort();
    }

    /* Copy data at right position: */
    memcpy (buffer->data + bytes, data, length);

    /* This is the number of bytes that is actual data. */
    bytes += length;

    /* We have new data in our buffer, now to actually parse it: */

    if (messageLength == 0)
        /* If we haven't got a message length yet: */
    {
        if (bytes >= INT)
            /* If there are enough bytes to get message length: */
        {
            messageLength = intFromChars (buffer->data);
            realLength = messageLength;

            if (messageLength > MESSAGE_LIMIT )
            {
                if ((bytes - INT) > messageLength)
                {
                    temp = malloc (MESSAGE_LIMIT + INT);
                    if (temp == NULL)
                        abort ();
                    memcpy (temp, buffer->data + messageLength + INT, (bytes - INT) - messageLength);
                    memcpy (buffer->data + MESSAGE_LIMIT + INT, temp, (bytes - INT) - messageLength);
                    free (temp);
                    bytes = MESSAGE_LIMIT + ((bytes) - messageLength);
                    messageLength = MESSAGE_LIMIT;
                }
                else
                {
                    messageLength = MESSAGE_LIMIT;
                    bytes = MESSAGE_LIMIT + INT;
                    realLength = messageLength;
                }
            }

            if (bytes >= (realLength + INT))
            {
                /* Get the message into a new object and remove from buffer: */
                messageData = getMessage (buffer, bytes, messageLength + INT);

                bytes -= (messageLength + INT);
                messageLength = 0;

                return messageData;
            }
            else
            {
                /* Wait for more data: */
                return NULL;
            }
        }
        else
            /* Return and wait for more data: */
        {
            return NULL;
        }
    }
    else
        /* If we have a message length already: */
    {
        if ((bytes - INT) >= realLength)
        {
            /* Get the message into a new object and remove from buffer: */
            messageData = getMessage(buffer, bytes, messageLength + INT);

            bytes = bytes - (messageLength + INT);
            messageLength = 0;
            realLength = 0;

            return messageData;
        }
    }

    return NULL;
}

struct data *newData (char *data, int length)
{
    struct data *newDataObject;

    newDataObject = malloc (sizeof data);
    if (newDataObject == NULL)
        abort ();

    newDataObject->length = length;
    if (length > 0)
    {
        newDataObject->data = malloc (length);
        if (newDataObject->data == NULL)
            abort ();
        if (data != NULL)
            memcpy (newDataObject->data, data, length);
    }
    else
    {
        newDataObject->data = NULL;
    }

    return newDataObject;
}

void deleteData (struct data *toDelete)
{
    if (toDelete->data)
    {
        free (toDelete->data);
    }
    free (toDelete);
}

char *dataToStr (struct data *toData, const char *format, int flag)
{
    char *newStr;
    char theChar[(CHAR_BIT * 4) + STRING_TERMINATE];
    int strLength;
    int index;
    int position;

    strLength = 0;

    /* Get length to allocate: */
    for (index = 0; index < toData->length; index++)
    {
        if (flag == 1)
        {
            snprintf (theChar, (CHAR_BIT * 4) + STRING_TERMINATE, format, toData->data[index] == '\0' ? ' ' : toData->data[index]);
            strLength += strlen(theChar);
        }
        else if (flag == 2)
        {
            snprintf (theChar, (CHAR_BIT * 4) + STRING_TERMINATE, format,
                      (
                          (toData->data[index] >= 'a' && (toData->data[index] <= 'z'))
                          ||
                          (toData->data[index] >= 'A' && (toData->data[index] <= 'Z'))
                      )
                      ? toData->data[index] : ' ');
            strLength += strlen(theChar);
        }
        else
        {
            snprintf (theChar, (CHAR_BIT * 4) + STRING_TERMINATE, format, toData->data[index]);
            strLength += strlen(theChar);
        }
    }

    newStr = malloc(strLength + STRING_TERMINATE);
    if (newStr == NULL)
        abort();
    position = 0;

    /* Copy data to string: */
    for (index = 0; index < toData->length; index++)
    {
        if (flag == 1)
        {
            snprintf (theChar, (CHAR_BIT * 4) + STRING_TERMINATE, format, toData->data[index] == '\0' ? ' ' : toData->data[index]);
            memcpy (newStr + position, theChar, strlen(theChar));
            position += strlen(theChar);
        }
        if (flag == 2)
        {
            snprintf (theChar, (CHAR_BIT * 4) + STRING_TERMINATE, format,
                      (
                          (toData->data[index] >= 'a' && (toData->data[index] <= 'z'))
                          ||
                          (toData->data[index] >= 'A' && (toData->data[index] <= 'Z'))
                      )
                      ? toData->data[index] : ' ');
            memcpy (newStr + position, theChar, strlen(theChar));
            position += strlen(theChar);
        }
        else
        {
            snprintf (theChar, (CHAR_BIT * 4) + STRING_TERMINATE, format, toData->data[index]);
            memcpy (newStr + position, theChar, strlen(theChar));
            position += strlen(theChar);
        }
    }

    newStr[position] = '\0'; /* Terminate. */

    return newStr;
}

struct data *newMessage (int length)
{
    struct data *newMessageObject;
    char stringLength[INT];

    newMessageObject = newData (NULL, INT + length);
    intBytesToChar (stringLength, length);

    memcpy (newMessageObject->data, stringLength, INT);

    return newMessageObject;
}

void appendData (struct data *appendTo, char *data, int startAt, int length)
{
    memcpy (appendTo->data + startAt, data, length);
}

struct data *newString (char *data, int length)
{
    struct data *newStr;
    char stringLength[INT];

    newStr = newData (NULL, INT + length);
    intBytesToChar (stringLength, length);

    memcpy (newStr->data, stringLength, INT);
    if (data != NULL)
        memcpy (newStr->data + INT, data, length);

    return newStr;
}

struct data *buildLogin (char *username, char *password, int version)
{
    struct data *   newLoginData;
    int             length;
    char            messageLengthBytes [INT];
    char            versionBytes       [INT];
    char            messageTypeBytes   [INT];
    struct data *   usernameData;
    struct data *   passwordData;

    length = INT + INT + INT + strlen(username) + INT + strlen(password) + INT;
    newLoginData = newData (NULL, length);

    intBytesToChar (messageLengthBytes, length - INT);
    intBytesToChar (versionBytes, SOULSEEK_VERSION);
    intBytesToChar (messageTypeBytes, SOULSEEK_MESSAGE_LOGIN);

    usernameData = newString (username, strlen(username));
    passwordData = newString (password, strlen(password));

    appendData (newLoginData, messageLengthBytes, 0, INT);
    appendData (newLoginData, messageTypeBytes, INT, INT);
    appendData (newLoginData, usernameData->data, INT + INT, usernameData->length);
    appendData (newLoginData, passwordData->data, INT + INT + usernameData->length, passwordData->length);
    appendData (newLoginData, versionBytes, INT + INT + usernameData->length + passwordData->length, INT);

    return newLoginData;
}
