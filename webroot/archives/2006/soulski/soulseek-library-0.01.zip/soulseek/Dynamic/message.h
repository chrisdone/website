/*-------------------------------- message.h ----------------------------------*/

#define ALLOCATE_LENGTH 512
#define STRING_TERMINATE 1
#define MESSAGE_LIMIT 4096
#define INT (CHAR_BIT / 2)
#define SOULSEEK_VERSION 156
#define SOULSEEK_MESSAGE_LOGIN 1

struct data
{
    unsigned int length;
    unsigned char *data;
};

void            intBytesToChar (unsigned char *, unsigned int);
int             intFromChars (unsigned char *);
struct data *   parseData (struct data *, char *, int);
struct data *   getMessage (struct data *, int, int);
struct data *   newData (char *, int);
struct data *   newString (char *, int);
struct data *   buildLogin (char *, char *, int);
char *          dataToStr (struct data *, const char *, int);
void            appendData (struct data *, char *, int, int);
void            deleteData (struct data *);
