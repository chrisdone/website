#if 0
#include <stdlib.h>
#include "soulseek.h"

void handleWelcome(soulseekdata *);

int main(int argc, char *argv[])
{
    //soulseekdata *loginData = buildSoulseekLogin("cinetics", "donkey", SOULSEEK_VERSION);
    //if (loginData == NULL) abort();

    /* Provide functions for message events. */
    soulseekhandlers *messageHandlers = newSoulseekHandlers();
    if (messageHandlers == NULL) abort();
    messageHandlers->welcomeHandler = handleWelcome;

    /* Extract all the messages from the data. */
    soulseekdata *parseMessage;
    soulseekparse *parseBuffer = newSoulseekBuffer(); /* Create a buffer structure. */
    if (parseBuffer == NULL) abort();

    /* Parse the data. */
    //parseSoulseekData(parseBuffer, messageHandlers, loginData->data, loginData->length.i);
    parseSoulseekData(parseBuffer, messageHandlers, testData->data, testData->length.i);

    /* Deconstruction. */
    deleteSoulseekBuffer(parseBuffer);
    deleteSoulseekData(loginData);
    deleteSoulseekHandlers(messageHandlers);

	return 0;
}

/* Welcome event handler. */
void handleWelcome(soulseekdata *welcomeData)
{
    /* Do stuff. */
    soulseekint messageType;
    messageType.i = 0;
    if (welcomeData->length.i >= SOULSEEK_INT_LENGTH)
    {
        memcpy(messageType.c, welcomeData->data, SOULSEEK_INT_LENGTH);
    }
    printf("handleWelcome() : %d : ", messageType.i);printSoulseekData(welcomeData->data, welcomeData->length.i);
}
#endif
