#ifndef _SOULSEEK_PRINT_H_
#define _SOULSEEK_PRINT_H_ 1

#include "data.h"

void printSoulseekData(unsigned char *data, int length, int toggle);

#endif
