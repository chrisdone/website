#include "data.h"
#include "parser.h"
#include <stdlib.h>
#include <memory.h>
#include <string.h>

/* --------------------------------------------------------------------------- */
/*                          The soulseekdata structure                         */
/* --------------------------------------------------------------------------- */

/* Construction. */
soulseekdata *newSoulseekData(char *data, int length)
{
    soulseekdata *newData = malloc(sizeof *newData);
    /* If there was an allocation failure, we should notify the caller. */
    if (newData == NULL) return NULL;

    /* Initial values. */
    newData->data = NULL;
    newData->length.i = 0;

    /* If we have been given values: */
    if (length > 0)
    {
        int setResult = setSoulseekData(newData, data, length);
        /* Check for errors. */
        if (!setResult)
        {
            free (newData);
            return NULL;
        }
    }

    return newData;
}

/* Deconstruction. */
void deleteSoulseekData(soulseekdata *toDelete)
{
    if (toDelete != NULL)
    {
        if (toDelete->data != NULL) free(toDelete->data);
        free(toDelete);
    }
}

/* Set length and allocate space for that length. */
int setSoulseekData(soulseekdata *setTo, char *data, int length)
{
    if (setTo == NULL) return 0;

    if (length > 0)
    {
          setTo->data = malloc(length);
          /* If allocation failed, return failure. */
          if (setTo->data == NULL) return 0;
          memset (setTo->data, 0, length);

          /* Success. */
          setTo->length.i = length;
          if (data != NULL)
          {
              /* If there is a string, copy it. */
              memcpy(setTo->data, data, length);
          }
          return 1;
    }

    /* Error. */
    return 0;
}

/* --------------------------------------------------------------------------- */
/*                         The soulseekbuffer structure                        */
/* --------------------------------------------------------------------------- */

/* Construction. */
soulseekparse *newSoulseekBuffer()
{
    soulseekparse *newBuffer = malloc(sizeof *newBuffer);
    /* If there was an allocation failure, we should notify the caller. */
    if (newBuffer == NULL) return NULL;

    /* Apply initial settings. */
    initialSoulseekBuffer (newBuffer);

    return newBuffer;
}

/* Deconstruction. */
void deleteSoulseekBuffer(soulseekparse *toDelete)
{
    if (toDelete != NULL)
    {
        if (toDelete->buffer != NULL) free (toDelete->buffer);
        free (toDelete);
    }
}

/* Default settings. */
void initialSoulseekBuffer (soulseekparse *buffer)
{
    buffer->buffer = NULL;
    buffer->bytesCopied = 0;
    buffer->state = SOULSEEK_STATE_GET_LEN;
    buffer->messageLength.i = 0;
    buffer->lengthBytes = 0;
    buffer->error = 0;
}

/* --------------------------------------------------------------------------- */
/*                      The soulseekhandlers structure                         */
/* --------------------------------------------------------------------------- */

soulseekhandlers *newSoulseekHandlers()
{
    soulseekhandlers *newHandlers = malloc(sizeof *newHandlers);
    if (newHandlers == NULL) return NULL;

    newHandlers->welcomeHandler = NULL;
    newHandlers->unknownHandler = NULL;
    newHandlers->donateHandler = NULL;
    newHandlers->connectToPeerHandler = NULL;
    newHandlers->privateMessageHandler = NULL;

    return newHandlers;
}

void deleteSoulseekHandlers(soulseekhandlers *toDelete)
{
    free (toDelete);
}

/* --------------------------------------------------------------------------- */
/*                   Functions to retieve data from soulseek messages.         */
/* --------------------------------------------------------------------------- */

int soulseekStringCopy(char *dest, char *src, int len, int limit)
{
    if (src != NULL)
    {
        if (len > SOULSEEK_INT_LENGTH)
        /* If there is actually a string pass the string length. */
        {
            /* Let's get the string length. */
            soulseekint stringLength;
            memcpy(stringLength.c, src, SOULSEEK_INT_LENGTH);
            if (limit > 0 && stringLength.i > limit) stringLength.i = limit;
            if (stringLength.i > 0)
            {
                if ((len - SOULSEEK_INT_LENGTH) >= stringLength.i)
                {
                    if (dest != NULL)
                    {
                        src += SOULSEEK_INT_LENGTH;
                        memcpy(dest, src, stringLength.i);
                        dest[stringLength.i + 1] = 0;
                        return 1;
                    }
                    else return stringLength.i;
                    /* Just return the string length. */
                }
            }
        }
    }

    /* Errors occoured while extracting the string. */
    return 0;
}

char *soulseekStringDup(char *src, int len, int limit, int *errorPtr, int *bytes)
{
    /* Set as no error as default. */
    *errorPtr = 0;
    *bytes = 0;

    if (src != NULL)
    {
        if (len > SOULSEEK_INT_LENGTH)
        /* If there is actually a string pass the string length. */
        {
            /* Let's get the string length. */
            soulseekint stringLength;
            memcpy(stringLength.c, src, SOULSEEK_INT_LENGTH);
            printf("String length is %d\n", stringLength.i);
            if (limit > 0 && stringLength.i > limit) stringLength.i = limit;
            if (stringLength.i > 0)
            {
                if ((len - SOULSEEK_INT_LENGTH) >= stringLength.i)
                {
                    src += SOULSEEK_INT_LENGTH;
                    char *newStr = malloc(stringLength.i + 1);
                    if (newStr == NULL)
                    {
                        *errorPtr = 1;goto error;
                    }
                    memcpy(newStr, src, stringLength.i);
                    newStr[stringLength.i + 1] = 0;
                    *bytes = stringLength.i;
                    return newStr;
                }
                else printf("! %d >= %d\n", (len - SOULSEEK_INT_LENGTH),
                        stringLength.i);
            }
        }
    }

    /* Errors occoured while extracting the string. */
    error:
    return NULL;
}
