#ifndef _SOULSEEK_MESSAGES_H_
#define _SOULSEEK_MESSAGES_H_ 1

#include "data.h"
#include "parser.h"

/* Message types: */
#define SOULSEEK_LOGIN (1)
#define SOULSEEK_DONATION_DAYS (92)
#define SOULSEEK_CONNECT_TO_PEER (18)
#define SOULSEEK_PRIVATE_MESSAGE (22)

/* Handler for the messages. */
void messageHandler(soulseekparse *buffer, soulseekhandlers *procedures);

soulseekdata *buildSoulseekLogin(char *user, char *pass, int version);
soulseekdata *buildSoulseekDonate();

#endif
