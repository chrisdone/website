#include <windows.h>
#include <winsock.h>
#include <stdio.h>
#include <stdlib.h>
#include "soulseek.h"

#define BUFFER_LEN 256

void handleWelcome(soulseekdata *);
void handleUnknown(soulseekdata *);
void handlePrivateMessage(soulseekdata *);

int main(int argc, char *argv[])
{
	WORD        sockVersion;
	WSADATA     wsaData;
	int         connectResult;
	LPHOSTENT   hostEntry;
	SOCKET      theSocket;
	SOCKADDR_IN serverInfo;
	int         recvLength;
	char        buffer[BUFFER_LEN];
    unsigned char *tempStr;

	serverInfo.sin_family = AF_INET;

	sockVersion = MAKEWORD (1, 1);

	WSAStartup (sockVersion, &wsaData);

	hostEntry = gethostbyname ("sk6.slsknet.org");
	if (!hostEntry)
	{
	    puts("Cannot resolve hostname.");
	    WSACleanup();
	    return -1;
	}
	else
	{
	    puts("Resolved hostname.");
	}

	theSocket = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (theSocket == INVALID_SOCKET)
	{
	    puts("Failed to create socket.");
	    WSACleanup();
	    return -1;
	}

	serverInfo.sin_addr = *((LPIN_ADDR)*hostEntry->h_addr_list);
	serverInfo.sin_port = htons(2240);

	connectResult = connect(theSocket, (LPSOCKADDR)&serverInfo,
        sizeof(struct sockaddr));

	if (connectResult == SOCKET_ERROR)
	{
		puts("Could not connect.");
	    WSACleanup();
		return -1;
	}
    else
    {
        puts("Connected to Soulseek network server.");
    }

    soulseekdata *loginData = buildSoulseekLogin("cinetics", "donkey",
        SOULSEEK_VERSION);
    if (loginData == NULL) abort();

    /* Provide functions for message events. */
    soulseekhandlers *messageHandlers = newSoulseekHandlers();
    if (messageHandlers == NULL) abort();
    messageHandlers->unknownHandler = handleUnknown;
    messageHandlers->privateMessageHandler = handlePrivateMessage;

    /* Create a buffer structure. */
    soulseekparse *parseBuffer = newSoulseekBuffer();
    if (parseBuffer == NULL) abort();

    send (theSocket, loginData->data, loginData->length.i, 0);
    /* Parse all the messages in the data. */
    int i = 0;
    while ((recvLength = recv (theSocket, buffer, BUFFER_LEN, 0)) > 0)
    {
        /* Parse the data. */
        parseSoulseekData(parseBuffer, messageHandlers, buffer, recvLength);
    }

    if (recvLength == -1)
    {
        printf("Error on socket.\r\n");
    }
    else if (recvLength == 0)
    {
        printf("Connection closed.\r\n");
    }

    /* Deconstruction. */
    deleteSoulseekBuffer(parseBuffer);
    deleteSoulseekData(loginData);
    deleteSoulseekHandlers(messageHandlers);

    closesocket(theSocket);

	WSACleanup();

	return 0;
}

/* Welcome event handler. */
void handleWelcome(soulseekdata *welcomeData)
{
    return;
    /* Do stuff. */
    printf("handleWelcome() : ");printSoulseekData(welcomeData->data,
        welcomeData->length.i, 0);
}


/* Unknown events handler. */
void handleDonationDays(soulseekdata *donationDays)
{
    soulseekint daysLeft;
    daysLeft.i = 0;
    if (donationDays->length.i >= (SOULSEEK_INT_LENGTH * 2))
    {
        memcpy(daysLeft.c, donationDays->data + SOULSEEK_INT_LENGTH,
            SOULSEEK_INT_LENGTH);
    }
    printf("handleDonationDays() : %d", daysLeft.i);
}

/* Unknown events handler. */
void handleUnknown(soulseekdata *unknownData)
{
    /* Do stuff. */
    soulseekint messageType;
    messageType.i = 0;
    if (unknownData->length.i >= SOULSEEK_INT_LENGTH)
    {
        memcpy(messageType.c, unknownData->data, SOULSEEK_INT_LENGTH);
    }
    printf("handleUnknown() : Message type: %d :\n ", messageType.i);
    printSoulseekData(unknownData->data, unknownData->length.i, 1);
}

void handleConnectToPeer(soulseekdata *unknownData)
{
    printf("handleConnectToPeer() : ");
    printSoulseekData(unknownData->data, unknownData->length.i, 1);
}

void handlePrivateMessage(soulseekdata *messageData)
{
    printf("handlePrivateMessage() : ");
    if (messageData->length.i <= SOULSEEK_INT_LENGTH) return;

    printSoulseekData(messageData->data, messageData->length.i, 1);

    unsigned char *tempData = messageData->data;
    unsigned int tempLength = messageData->length.i;
    soulseekint messageID = {0,};
    soulseekint timeStamp = {0,};
    char *user;
    char *message;

    /* We must not assume that message lengths will always be complete. */
    /* Just incase. */

    /* Move along the data. */
    tempData += SOULSEEK_INT_LENGTH;
    tempLength -= SOULSEEK_INT_LENGTH;

    /* First get the messageID. */
    if (tempLength >= SOULSEEK_INT_LENGTH)
    {
        memcpy(messageID.c, tempData, SOULSEEK_INT_LENGTH);
    }
    else return;

    /* Move along the data. */
    tempData += SOULSEEK_INT_LENGTH;
    tempLength -= SOULSEEK_INT_LENGTH;

    /* First get the messageID. */
    if (tempLength >= SOULSEEK_INT_LENGTH)
    {
        memcpy(timeStamp.c, tempData, SOULSEEK_INT_LENGTH);
    }
    else return;

    printf("messageID: %d\n", messageID.i);
    printf("timeStamp: %d\n", timeStamp.i);

    /* Now to get the user name and then the message. */

    /* Move along the data. */
    tempData += SOULSEEK_INT_LENGTH;
    tempLength -= SOULSEEK_INT_LENGTH;

    int allocError;
    int bytesCopied;

    user = soulseekStringDup(tempData, tempLength, SOULSEEK_USER_LIMIT, &allocError, &bytesCopied);
    /* Abort for now, to be safe. */
    if (allocError) abort();
    if (user == NULL) return; /* No need to continue. */

    printf("bytesCopied: %d\n", bytesCopied);
    tempData += bytesCopied + SOULSEEK_INT_LENGTH;
    tempLength -= (bytesCopied + SOULSEEK_INT_LENGTH);

    message = soulseekStringDup(tempData, tempLength, SOULSEEK_MSG_LIMIT, &allocError, &bytesCopied);
    /* Abort for now, to be safe. */
    if (allocError) abort();
    if (message == NULL)
    {
        free(user); /* Clear what I allocated. */
        return; /* No need to continue. */
    }

    printf("Username: %s\n", user);
    printf("Message: %s\n", message);

    free(user);
    free(message);
}
