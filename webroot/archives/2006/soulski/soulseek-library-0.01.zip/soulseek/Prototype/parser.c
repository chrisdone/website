#include "parser.h"
#include "messages.h"
#include "data.h"
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

void parseSoulseekData(soulseekparse *buffer, soulseekhandlers *procedures, unsigned char *data, int length)
{
    if (length < 1)
    {
        buffer->state = SOULSEEK_DATA_ERROR;
        return;
    }

    for (int exitLoop = 0; exitLoop != SOULSEEK_EXIT_LOOP;)
    {
        switch (buffer->state)
        {
            case SOULSEEK_STATE_GET_LEN:
            {
                #ifdef SOULSEEK_DEBUG
                printf("State SOULSEEK_STATE_GET_LEN:\n");
                #endif
                exitLoop = getMessageLength(buffer, &data, &length);
                #ifdef SOULSEEK_DEBUG
                printf("End of state.\n\n");
                #endif
                break;
            }
            case SOULSEEK_STATE_GET_MSG:
            {
                #ifdef SOULSEEK_DEBUG
                printf("State SOULSEEK_STATE_GET_MSG:\n");
                #endif
                exitLoop = getMessage(buffer, procedures, &data, &length);
                #ifdef SOULSEEK_DEBUG
                printf("End of state.\n\n");
                #endif
                break;
            }
            default: exitLoop = SOULSEEK_EXIT_LOOP;
        }
    }

}

static int getMessage(soulseekparse *buffer, soulseekhandlers *procedures, unsigned char **data, int *length)
{
    if (*length < 1) return SOULSEEK_EXIT_LOOP;

    /* Establish number of bytes to copy: */
    int copyLength = *length > buffer->messageLength.i ? buffer->messageLength.i : *length;
    if (copyLength + buffer->bytesCopied > buffer->messageLength.i)
    {
        copyLength = buffer->messageLength.i - buffer->bytesCopied;
    }

    #ifdef SOULSEEK_DEBUG
    printf("   Bytes given:\t\t%d\n", *length);
    printf("   Data:\t\t");printSoulseekData (*data, *length);
    printf("   Bytes to copy:\t%d\n", copyLength);
    printf("   Copied so far:\t%d\n", buffer->bytesCopied);
    #endif

    /* Copy the data: */
    if (buffer->buffer != NULL) memcpy(buffer->buffer + buffer->bytesCopied, *data, copyLength);

    /* Update the poiters. */
    *length -= copyLength;
    *data += copyLength;

    /* Update number of bytes: */
    buffer->bytesCopied += copyLength;

    if (buffer->bytesCopied == buffer->messageLength.i)
    /* We have the complete message. */
    {
        if (buffer->buffer != NULL)
        {
            //#ifdef SOULSEEK_DEBUG
            printf(" * Message copied.\n");
            //#endif
            messageHandler (buffer, procedures);
        }
        //#ifdef SOULSEEK_DEBUG
        else printf(" * Message ignored.\n");
        //#endif

        /* Reset to initial buffer settings. */
        initialSoulseekBuffer (buffer);
    }

    return 0; /* Don't exit state machine. */
}

static int getMessageLength(soulseekparse *buffer, unsigned char **data, int *length)
{
    if (*length < 1) return SOULSEEK_EXIT_LOOP; /* Exit state machine. */

    /* Establish the length: */
    int copyLength;
    /* Grab four or less bytes: */
    copyLength = (*length >= SOULSEEK_INT_LENGTH ? SOULSEEK_INT_LENGTH : *length);
    /* Subtract the number of bytes we've already got: */
    if (copyLength + buffer->lengthBytes > SOULSEEK_INT_LENGTH)
        copyLength = SOULSEEK_INT_LENGTH - buffer->lengthBytes;

    #ifdef SOULSEEK_DEBUG
    printf("   Bytes given:\t\t%d\n", *length);
    printf("   Data:\t\t");printSoulseekData (*data, *length);
    printf("   Bytes to copy:\t%d\n", copyLength);
    printf("   Copied so far:\t%d\n", buffer->lengthBytes);
    #endif

    /* Copy the data. */
    memcpy(buffer->messageLength.c + buffer->lengthBytes, *data, copyLength);

    /* Update the number of bytes copied. */
    buffer->lengthBytes += copyLength;

    if (buffer->lengthBytes == SOULSEEK_INT_LENGTH)
    {
        /* Check for sanity. */
        if (buffer->messageLength.i < 0)
        {
            /* We need to bail out and return an error. */
            /* We haven't allocated anything yet so there is nothing to delete. */
            buffer->state = SOULSEEK_DATA_ERROR;
            return SOULSEEK_EXIT_LOOP;
        }

        /* We have the message length, now allocate: */
        if (buffer->messageLength.i <= SOULSEEK_MSG_MAX) /* Check limit. */
            buffer->buffer = malloc(buffer->messageLength.i);

        if ((buffer->buffer == NULL) && (buffer->messageLength.i <= SOULSEEK_MSG_MAX))
        /* An allocation error occoured. */
        {
            #ifdef SOULSEEK_DEBUG
            printf(" * Error occoured.\n");
            #endif
            buffer->error = SOULSEEK_ALLOC_ERROR;
            return SOULSEEK_EXIT_LOOP; /* Exit state machine. */
        }
        else
        /* Everything was a success. */
        {
            buffer->state = SOULSEEK_STATE_GET_MSG; /* Go to next state. */

            #ifdef SOULSEEK_DEBUG
            printf("   Bytes copied:\t%d\n", copyLength);
            printf(" * Total message length found.\n");
            if (buffer->messageLength.i <= SOULSEEK_MSG_MAX)
            {
                printf("   Message length:\t%d\n", buffer->messageLength.i);
            }
            else
            {
                printf("   Message length:\t%d (Exceeds limit: %d)\n", buffer->messageLength.i, SOULSEEK_MSG_MAX);
            }
            #endif
            /* Update pointers. */
            *data += copyLength;
            *length -= copyLength;

            return 0; /* Don't exit state machine. */
        }
    }

    #ifdef SOULSEEK_DEBUG
    printf("   Bytes copied:\t%d\n", copyLength);
    printf(" * Do not yet have message length.\n");
    #endif

    return SOULSEEK_EXIT_LOOP; /* Exit state machine. */
}
