#include "data.h"
#include "print.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

void printSoulseekData(unsigned char *data, int length, int toggle)
{
    /* Check data. */
    if (length == 0 || data == NULL)
    {
        puts(" * This soulseekdata structure has no data and therefore cannot be printed.");
        return;
    }

    /* It's okay to print. */

    for (int i = 0; i < length; i++)
    {
        /* Print only readable characters. */
        if (!toggle && (isalpha(data[i]) || isdigit(data[i]) ||
            ispunct(data[i]) || isspace(data[i])))
        {
            printf("%c", data[i]);
        }
        /* Print the rest as hex. */
        else
        {
            printf("\\0x%x", data[i]);
        }
    }
    puts ("");
}
