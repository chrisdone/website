#include "data.h"
#include "messages.h"
#include <stdlib.h>
#include <memory.h>
#include <string.h>

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/*                       Functions for handling messages.                       */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

void messageHandler(soulseekparse *buffer, soulseekhandlers *procedures)
{
    /* We don't check the data because we are assuming it has been checked for us. */
    soulseekdata *newMessage;
    newMessage = newSoulseekData(buffer->buffer, buffer->messageLength);

    if (newMessage->length.i >= SOULSEEK_INT_LENGTH)
    {
        soulseekint messageType;
        memcpy(messageType.c, newMessage->data, SOULSEEK_INT_LENGTH);
        switch (messageType.i)
        {
            case SOULSEEK_LOGIN:
            {
                if (procedures->welcomeHandler != NULL)
                    procedures->welcomeHandler (newMessage);
                break;
            }
            case SOULSEEK_DONATION_DAYS:
            {
                if (procedures->donateHandler != NULL)
                    procedures->donateHandler (newMessage);
                break;
            }
            case SOULSEEK_CONNECT_TO_PEER:
            {
                if (procedures->connectToPeerHandler != NULL)
                    procedures->connectToPeerHandler (newMessage);
                break;
            }
            case SOULSEEK_PRIVATE_MESSAGE:
            {
                if (procedures->privateMessageHandler != NULL)
                    procedures->privateMessageHandler (newMessage);
                break;
            }
            default:
            {
                if (procedures->unknownHandler != NULL)
                    procedures->unknownHandler (newMessage);
            }
        }
    }

    deleteSoulseekData(newMessage);
}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/*                       Functions for constructing messages                    */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

soulseekdata *buildSoulseekLogin(char *user, char *pass, int version)
{
    soulseekdata *newData = newSoulseekData(NULL, 0);
    /* If there was an allocation failure, we should notify the caller. */
    if (newData == NULL) return NULL;

    /* Get string lengths: */
    soulseekint usernameLength;
    soulseekint passwordLength;
    usernameLength.i = strlen(user);
    passwordLength.i = strlen(pass);

    /* Establish the length: */
    soulseekint messageLength;
    messageLength.i = 0;
    messageLength.i += SOULSEEK_INT_LENGTH; /* Message type. */
    messageLength.i += SOULSEEK_INT_LENGTH; /* Username length. */
    messageLength.i += usernameLength.i;        /* Username. */
    messageLength.i += SOULSEEK_INT_LENGTH; /* Password length. */
    messageLength.i += passwordLength.i;        /* Password. */
    messageLength.i += SOULSEEK_INT_LENGTH; /* Version length. */

    /* Allocate data. */
    if (!setSoulseekData(newData, NULL, messageLength.i + SOULSEEK_INT_LENGTH))
    {
        /* On error delete what we allocated and return error. */
        deleteSoulseekData(newData);
        return NULL;
    }

    /* Message type and protocol version. */
    soulseekint messageType;
    soulseekint soulseekVersion;
    messageType.i = SOULSEEK_LOGIN;
    soulseekVersion.i = version;

    /* Finally, copy the message data: */
    unsigned char *buffer;
    buffer = newData->data;

    memcpy(buffer, messageLength.c, SOULSEEK_INT_LENGTH); /* Message length. */
    buffer += SOULSEEK_INT_LENGTH;

    memcpy(buffer, messageType.c, SOULSEEK_INT_LENGTH); /* Message type. */
    buffer += SOULSEEK_INT_LENGTH;

    /* Username string: */
    memcpy(buffer, usernameLength.c, SOULSEEK_INT_LENGTH); /* Username length. */
    buffer += SOULSEEK_INT_LENGTH;
    memcpy(buffer, user, usernameLength.i); /* Username string. */
    buffer += usernameLength.i;

    /* Password string: */
    memcpy(buffer, passwordLength.c, SOULSEEK_INT_LENGTH); /* Username length. */
    buffer += SOULSEEK_INT_LENGTH;
    memcpy(buffer, pass, passwordLength.i); /* Username string. */
    buffer += passwordLength.i;

    memcpy(buffer, soulseekVersion.c, SOULSEEK_INT_LENGTH); /* Protocol version: */

    /* End of copying. */

    return newData;
}

soulseekdata *buildSoulseekDonate()
{
    soulseekdata *newData = newSoulseekData(((char [8]){'\4','\0','\0','\0', 92, '\0', '\0', '\0'}), 8);
    /* If there was an allocation failure, we should notify the caller. */
    if (newData == NULL) return NULL;

    return newData;
}
