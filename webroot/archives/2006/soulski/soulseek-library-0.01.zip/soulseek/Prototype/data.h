#ifndef _SOULSEEK_DATA_H_
#define _SOULSEEK_DATA_H_ 1

#define SOULSEEK_INT_LENGTH 4
#define SOULSEEK_VERSION 156
#define SOULSEEK_MSG_MAX (1024 * 1024)
#define SOULSEEK_USER_LIMIT 64
#define SOULSEEK_MSG_LIMIT 1024

typedef struct soulseekdata soulseekdata;
typedef struct soulseekparse soulseekparse;
typedef struct soulseekhandlers soulseekhandlers;
typedef union soulseekint soulseekint;

union soulseekint
{
    unsigned char c[4];
    unsigned int i;
};

struct soulseekhandlers
{
    void (*welcomeHandler)(soulseekdata *);
    void (*unknownHandler)(soulseekdata *);
    void (*donateHandler)(soulseekdata *);
    void (*connectToPeerHandler)(soulseekdata *);
    void (*privateMessageHandler)(soulseekdata *);
};

struct soulseekparse
{
    unsigned char *buffer;
    int bytesCopied;
    int state;
    soulseekint messageLength;
    char lengthBytes;
    int error;
};

struct soulseekdata
{
    unsigned char *data;
    soulseekint length;
};

/* Message construction/deconstruction. */
soulseekdata *newSoulseekData();
void deleteSoulseekData(soulseekdata *);
int setSoulseekData(soulseekdata *setTo, char *data, int length);

/* Buffer construction/deconstruction. */
soulseekparse *newSoulseekBuffer();
void deleteSoulseekBuffer(soulseekparse *toDelete);
void initialSoulseekBuffer (soulseekparse *buffer);

/* Handlers construction/deconstruction. */
soulseekhandlers *newSoulseekHandlers();
void deleteSoulseekHandlers(soulseekhandlers *toDelete);

/* Functions for extracting data from soulseek messages.*/
int soulseekStringCopy(char *dest, char *src, int len, int limit);
char *soulseekStringDup(char *src, int len, int limit, int *error, int *bytes);

#endif
