#ifndef _SOULSEEK_PARSER_H_
#define _SOULSEEK_PARSER_H_ 1

#include "data.h"

/* States: */
#define SOULSEEK_STATE_GET_LEN 1
#define SOULSEEK_STATE_GET_MSG 2

#define SOULSEEK_EXIT_LOOP 1

/* Error messages. */
#define SOULSEEK_ALLOC_ERROR 1
#define SOULSEEK_DATA_ERROR 2
void parseSoulseekData(soulseekparse *buffer, soulseekhandlers *procedures, unsigned  char *data, int length);

/* Message parsing states. */
static int getMessageLength(soulseekparse *buffer, unsigned  char **data, int *length);
static int getMessage(soulseekparse *buffer, soulseekhandlers *procedures, unsigned char **data, int *length);

#endif
