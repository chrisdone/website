#include <stdlib.h>
#include <stdio.h>
#include <windows.h>

LRESULT CALLBACK windowProcedure (HWND, UINT, WPARAM, LPARAM);

int main(int argc, char *argv[])
{
    HINSTANCE soulseekLibrary;
    HWND mainWindow;
    MSG messages;
    WNDCLASSEX wincl;

    wincl.hInstance = GetModuleHandle (0);
    wincl.lpszClassName = "SoulseekSample";
    wincl.lpfnWndProc = windowProcedure;
    wincl.style = 0;
    wincl.cbSize = sizeof (WNDCLASSEX);
    wincl.hIcon  = NULL;
    wincl.hIconSm  = NULL;
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName  = NULL;
    wincl.cbClsExtra = 0;
    wincl.cbWndExtra = 0;
    wincl.hbrBackground = NULL;
    if (!RegisterClassEx (&wincl)) return FALSE;

    soulseekLibrary = LoadLibrary ("soulseek.dll");
    if (!soulseekLibrary)
        puts("Failed to load soulseek.dll.");
    else
        puts("Soulseek library loaded.");

    mainWindow = CreateWindow(
    "SoulseekSample",
    "SoulseekSample",
    WS_POPUP,
    0,
    0,
    0,
    0,
    HWND_DESKTOP,
    (HMENU)0,
    GetModuleHandle (0),
    NULL);

    while (GetMessage (&messages, NULL, 0, 0))
    {
        TranslateMessage(&messages);
        DispatchMessage(&messages);
    }

    return messages.wParam;
}

LRESULT CALLBACK windowProcedure (HWND windowHandle, UINT theMessage, WPARAM wParam, LPARAM lParam)
{
    HWND soulseekHandler;
    static char *userName = "cinetics";
    static char *passWord = "password";

    switch (theMessage)
    {
        case WM_CREATE:
        {
            soulseekHandler = CreateWindow(
            "SoulseekHandler",
            "SoulseekHandler",
            WS_POPUP,
            0,
            0,
            0,
            0,
            windowHandle,
            (HMENU)0,
            GetModuleHandle (0),
            NULL);
            if (!soulseekHandler)
                printf("Failed to create handler window.\n");
            else
                printf("Handler window created.\n");

            printf ("Username: %s\n", userName);
            printf ("Password: %s\n", passWord);

            puts("Logging in...");

            return 0;
        }
        default: return DefWindowProc (windowHandle, theMessage, wParam, lParam);
    }
}
