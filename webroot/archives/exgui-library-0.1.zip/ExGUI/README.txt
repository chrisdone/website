What this zip file contains
---------------------------

Dynamic/
The library along with source code.

Executable/
A program sample.

---------------------------

This was written with Code::Blocks, so that is what the project will be. I will be releasing Microsoft Visual C++ and Dev-C++ versions also.

If you are going to play with the controls, don't expect _anything_ to work. This is a pre-Alpha, just to give you a sample of the basics.

Don't worry, a usable Beta version will be out in a week or so.

---------------------------

Cheers,
Chris Done.
