
#include "buttoncontrol.h"
#include "theme.h"
#include <windows.h>

LRESULT CALLBACK buttonWindowProcedure (HWND windowHandle, UINT theMessage, WPARAM wParam, LPARAM lParam)
{
    BITMAP bitmapInfo;
    PAINTSTRUCT paintStruct;
    HDC drawingContext;
    HDC contextMemory;
    HBITMAP oldObject;
    RECT windowRect;
    char captionText [512];
    static HCURSOR newCursor;
    static int cursorSet = 0;
    static HBITMAP buttonLeft = NULL;
    static HBITMAP buttonMiddle = NULL;
    static HBITMAP buttonRight = NULL;
    static HBITMAP buttonLeftPressed = NULL;
    static HBITMAP buttonMiddlePressed = NULL;
    static HBITMAP buttonRightPressed = NULL;

    static BOOL fInWindow = FALSE;
    TRACKMOUSEEVENT tme;

    switch (theMessage)
    {
        case WM_MOUSEMOVE:
        {
            if (!cursorSet)
            {
                newCursor = LoadCursor (0, IDC_HAND);
                cursorSet = 1;
            }
            break;
        }
        case WM_LBUTTONDOWN:
        {
            if (!fInWindow)
            {
               fInWindow = TRUE;
               tme.cbSize = sizeof (TRACKMOUSEEVENT);
               tme.dwFlags = TME_LEAVE;
               tme.hwndTrack = windowHandle;
               TrackMouseEvent (&tme);
            }

            SetWindowLong (windowHandle, GWL_USERDATA, (LONG)1);
            RedrawWindow (windowHandle, NULL, NULL, RDW_INVALIDATE);
            break;
        }
        case WM_MOUSELEAVE:
        {
            fInWindow = FALSE;
            SetWindowLong (windowHandle, GWL_USERDATA, (LONG)0);
            RedrawWindow (windowHandle, NULL, NULL, RDW_INVALIDATE);
            break;
        }
        case WM_LBUTTONUP:
        {
            if (fInWindow)
            {
                SetWindowLong (windowHandle, GWL_USERDATA, (LONG)0);
                RedrawWindow (windowHandle, NULL, NULL, RDW_INVALIDATE);
                SendMessage (GetParent(windowHandle), WM_COMMAND, GetWindowLong(windowHandle, GWL_ID), 0);
            }
            break;
        }
        case WM_SIZE:
        {
            GetWindowRect (windowHandle, &windowRect);
            if (HIWORD(lParam) > BUTTON_HEIGHT)
            SetWindowPos (windowHandle, NULL, windowRect.left, windowRect.top, LOWORD(lParam), BUTTON_HEIGHT, SWP_NOMOVE);
            break;
        }
        case WM_SETCURSOR:
        {
            if (cursorSet) SetCursor(newCursor);
            break;
        }
        case WM_CREATE:
        {
            SetWindowLong (windowHandle, GWL_USERDATA, 0);
            break;
        }
        case WM_PAINT:
        {
            if (buttonLeft == NULL) buttonLeft = getControlBitmap ("button", "buttonLeft");
            if (buttonMiddle == NULL) buttonMiddle = getControlBitmap ("button", "buttonMiddle");
            if (buttonRight == NULL) buttonRight = getControlBitmap ("button", "buttonRight");
            if (buttonLeftPressed == NULL) buttonLeftPressed = getControlBitmap ("button", "buttonLeftPressed");
            if (buttonMiddlePressed == NULL) buttonMiddlePressed = getControlBitmap ("button", "buttonMiddlePressed");
            if (buttonRightPressed == NULL) buttonRightPressed  = getControlBitmap ("button", "buttonRightPressed");

            GetWindowRect (windowHandle, &windowRect);

            PAINTSTRUCT ps;
            HDC windowDC = BeginPaint (windowHandle, &ps);

            if ((LONG)GetWindowLong (windowHandle, GWL_USERDATA) == 0)
            {
                GetObject (buttonLeft, sizeof bitmapInfo, &bitmapInfo);
                drawTransparentBitmap (windowDC, buttonLeft, 0, 0, 0xFF00FF);

                int drawPosition = bitmapInfo.bmWidth;
                int i;
                for (i = 0; i < ((windowRect.right - windowRect.left) / bitmapInfo.bmWidth) + 1; i++)
                {
                    if ((drawPosition + bitmapInfo.bmWidth) > windowRect.right - windowRect.left - bitmapInfo.bmWidth)
                        break;
                    drawTransparentBitmap (windowDC, buttonMiddle, drawPosition, 0, 0xFF00FF);
                    drawPosition+=bitmapInfo.bmWidth;
                }

                GetObject (buttonRight, sizeof bitmapInfo, &bitmapInfo);
                drawTransparentBitmap (windowDC, buttonRight, windowRect.right - windowRect.left - bitmapInfo.bmWidth, 0, 0xFF00FF);
            }
            else
            {
                GetObject (buttonLeftPressed, sizeof bitmapInfo, &bitmapInfo);
                drawTransparentBitmap (windowDC, buttonLeftPressed, 0, 0, 0xFF00FF);

                int drawPosition = bitmapInfo.bmWidth;
                int i;
                for (i = 0; i < ((windowRect.right - windowRect.left) / bitmapInfo.bmWidth) + 1; i++)
                {
                    if ((drawPosition + bitmapInfo.bmWidth) > windowRect.right - windowRect.left - bitmapInfo.bmWidth)
                        break;
                    drawTransparentBitmap (windowDC, buttonMiddlePressed, drawPosition, 0, 0xFF00FF);
                    drawPosition+=bitmapInfo.bmWidth;
                }

                GetObject (buttonRightPressed, sizeof bitmapInfo, &bitmapInfo);
                drawTransparentBitmap (windowDC, buttonRightPressed, windowRect.right - windowRect.left - bitmapInfo.bmWidth, 0, 0xFF00FF);
            }

			SetTextColor (windowDC, RGB (255, 255, 255));
            GetWindowText (windowHandle, captionText, 511);

            HPEN newPen = CreatePen (PS_SOLID, 1, RGB (255, 255, 255)); /* Border colour. */
            HPEN oldPen = SelectObject (windowDC, newPen);

            drawText (windowDC, captionText,
            0, 0,
            windowRect.right - windowRect.left,
            windowRect.bottom - windowRect.top,
            getMainFont (),
            DT_CENTER);

            SelectObject (windowDC, oldPen);

            EndPaint (windowHandle, &ps);

            break;
        }
        case WM_ERASEBKGND:
        {
            return 0;
        }
        default:
            return DefWindowProc (windowHandle, theMessage, wParam, lParam);
    }

    return 0;
}
