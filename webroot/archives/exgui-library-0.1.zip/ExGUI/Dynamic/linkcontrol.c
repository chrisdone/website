/* ------------------------------------------------------------------- */
/* This code has been commented and recoded so that it is correct.     */
/* ------------------------------------------------------------------- */

#include "linkcontrol.h"
#include "theme.h" /* We need this for our bitmaps. */

#include <windows.h>

/* ------------------------------------------------------------------- */
/* Window procedure for handling all the events of the link button.    */
/* ------------------------------------------------------------------- */

LRESULT CALLBACK linkWindowProcedure (HWND windowHandle, UINT theMessage, WPARAM wParam, LPARAM lParam)
{
    /* Used for changing the cursor icon. */
    static HCURSOR newCursor = IDC_HAND;

    /* Our link image. */
    static HBITMAP linkBitmap = NULL;

    /* Used for painting to the window. */
    /* (Used in the WM_PAINT case) */
    PAINTSTRUCT paintStruct;
    HDC windowDC;
    HDC bitmapDC;
    BITMAP bitmapInfo;

    /* Used for clarity of code. */
    /* (Used in the WM_PAINT case) */
    int windowWidth;
    int windowHeight;
    RECT windowRect;

    char linkCaption[513];

    /* ----------------------------------------------- */
    /* No more objects are declared beyond this point. */
    /* ----------------------------------------------- */

    switch (theMessage)
    {
        case WM_CREATE:
        {
            /* Load the bitmap. */
            linkBitmap = getControlBitmap("link", "link");
            newCursor = LoadCursor(0, IDC_HAND);

            break;
        }
        case WM_SETCURSOR:
        {
            SetCursor(newCursor);

            break;
        }
        case WM_DESTROY:
        /* Make sure we clear up our objects when the window is destroyed. */
        {
            if (newCursor != NULL) DestroyCursor (newCursor);

            break;
        }
        case WM_LBUTTONUP:
        /* The button was pressed, woohoo! */
        {
            /* Forward it to our parent. */
            /* If this has no parent, it's not our fault. */
            /* Note: Might rethink this later. */
            SendMessage (GetParent(windowHandle), WM_COMMAND, GetWindowLong(windowHandle, GWL_ID), 0);
            break;
        }
        case WM_ERASEBKGND:
        /* Clears the DC. */
        {
            /* We don't want it to clear our window to avoid flickering. */
            break;
        }
        case WM_PAINT:
        {
            /* Get window dimensions. */
            GetWindowRect (windowHandle, &windowRect);
            windowWidth = windowRect.right - windowRect.left;
            windowHeight = windowRect.bottom - windowRect.top;

            /* Get our window DC. */
            windowDC = BeginPaint (windowHandle, &paintStruct);

            /* Draw link bitmap. */
            GetObject (linkBitmap, sizeof bitmapInfo, &bitmapInfo);
            drawTransparentBitmap (windowDC, linkBitmap, 0, ((windowHeight) / 2) - (windowHeight / 2), 0xFF00FF);

            GetWindowText (windowHandle, linkCaption, 512);
            SetTextColor (windowDC, RGB (0, 0, 0));
            drawText (windowDC, linkCaption, 15, 0, windowWidth, windowHeight, getMainFont (), DT_CENTER);

            /* Delete the DC. */
            EndPaint (windowHandle, &paintStruct);
            break;
        }
        default: return DefWindowProc (windowHandle, theMessage, wParam, lParam);
    }

    /* We don't have to forward messages to anyone. */
    return 0;
}