#include "layoutframecontrol.h"
#include <windows.h>

LRESULT CALLBACK layoutFrameWindowProcedure (HWND windowHandle, UINT theMessage, WPARAM wParam, LPARAM lParam)
{
    switch (theMessage)
    {
        case WM_COMMAND:
        /* User controls send this message. */
        {
            /* We need to forward these messages to the main window and ignore them. */
            SendMessage (GetParent(windowHandle), theMessage, wParam, lParam);

            return 0; /* Finish up here. */
        }
        default: return DefWindowProc (windowHandle, theMessage, wParam, lParam);
    }
}
