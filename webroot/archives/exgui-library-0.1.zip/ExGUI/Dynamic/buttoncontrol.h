#include <windows.h>

#define BUTTON_HEIGHT 34

LRESULT CALLBACK buttonWindowProcedure (HWND, UINT, WPARAM, LPARAM);
