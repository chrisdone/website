#include <windows.h>

LRESULT CALLBACK linkWindowProcedure (HWND, UINT, WPARAM, LPARAM);
