#include <windows.h>

LRESULT CALLBACK layoutFrameWindowProcedure (HWND, UINT, WPARAM, LPARAM);
