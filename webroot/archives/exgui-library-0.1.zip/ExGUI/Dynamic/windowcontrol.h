#include <windows.h>

#define EX_BORDER_WIDTH 8
#define EX_BORDER_HEIGHT 8
#define CURSOR_SIZENS       1
#define CURSOR_SIZEWE       2
#define CURSOR_SIZENESW     3
#define CURSOR_SIZENWSE     4
#define CURSOR_HAND         5
#define CURSOR_SIZEALL      6
#define CURSOR_ARROW        0
#define EX_BUTTON_NORMAL 0
#define EX_BUTTON_PRESSED 1
#define EX_BUTTON_HIGHLIGHTED 2

struct windowdata
{
    int closeButtonHover;
    int minimizeButtonHover;
    int maximizeButtonHover;
    int maximized;
};

struct windowdata *newWindowData ();
void deleteWindowData (struct windowdata *);

LRESULT CALLBACK dialogWindowProcedure (HWND windowHandle, UINT theMessage, WPARAM wParam, LPARAM lParam);
typedef LRESULT CALLBACK (*windowProcPointer)(HWND, UINT, WPARAM, LPARAM);

