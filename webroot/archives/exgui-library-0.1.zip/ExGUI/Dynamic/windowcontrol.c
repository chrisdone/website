/* ------------------------------------------------------------------- */
/* This code has been commented and recoded so that it is correct.     */
/* ------------------------------------------------------------------- */

#include "windowcontrol.h"
#include "theme.h"
#include <windows.h>

/* ------------------------------------------------------------------- */
/* Window procedure for handling all the events of the dialog window:  */
/* ------------------------------------------------------------------- */

LRESULT CALLBACK dialogWindowProcedure (HWND windowHandle, UINT theMessage, WPARAM wParam, LPARAM lParam)
{
    /* For cursor icon operations: */
    /* (Used in the WM_SETCURSOR case) */
    static int cursorType = CURSOR_ARROW;
    static int changeType = HTCAPTION;

    /* Function pointer to forward messages to: */
    /* (Used in the WM_USER case) */
    /* (Also used at the end of the function) */
    static windowProcPointer forwardTo = NULL;

    /* (Used in the WM_CREATE case) */
    UINT windowStyle;

    /* We use a windowdata structure to store extra information: */
    /* (Used in various places, initiliased in the WM_CREATE case) */
    struct windowdata *windowData;

    /* Positions of the mouse. */
    /* (Used in the WM_MOUSEMOVE case) */
    int xPosition;
    int yPosition;

    /* Used for window position and dimensions: */
    /* (Used in various areas) */
    /* (Used in the WM_MOUSEMOVE case) */
    RECT windowRect;

    /* Used for clarity of code. */
    /* (Used in the WM_MOUSEMOVE case) */
    int windowWidth;
    int windowHeight;

    /* This is the fancy looking background bitmap. */
    /* (Used in the WM_PAINT case) */
    static HBITMAP backdrop = NULL;
    static HBITMAP wbClose = NULL;
    static HBITMAP wbMinimize = NULL;
    static HBITMAP wbMaximize = NULL;
    static HBITMAP wbCloseHover = NULL;
    static HBITMAP wbMinimizeHover = NULL;
    static HBITMAP wbMaximizeHover = NULL;

    /* Used for painting to the window. */
    /* (Used in the WM_PAINT case) */
    PAINTSTRUCT paintStruct;
    HDC windowDC;
    HDC bitmapDC;
    BITMAP bitmapInfo;
    HBITMAP oldWindowObjects;
    HBRUSH newBrush;
    HPEN newPen;

    /* Used to create rounded region. */
    HRGN windowRegion;

    /* Used for limiting the size of the window. */
    MINMAXINFO *maxInfo;

    /* Used for workingwith the buttons: */
    static int buttonsLeft;
    static int buttonsTop;
    static int buttonsRight;
    static int buttonsBottom;

    /* ----------------------------------------------- */
    /* No more objects are declared beyond this point. */
    /* ----------------------------------------------- */

    switch (theMessage)
    {
        case WM_CREATE:
        /* Basic window creation procedures: */
        {
            #if 0
            /* We want to make sure our specific window styles are present. */
            windowStyle = GetWindowLong (windowHandle, GWL_STYLE);
            windowStyle |= WS_OVERLAPPEDWINDOW;
            windowStyle ^= WS_CAPTION;
            windowStyle ^= WS_BORDER;
            #endif

            /* If wrong things like WS_CHILD are added, it's not our problem. */
            SetWindowLong (windowHandle, GWL_STYLE, windowStyle);

            windowStyle = GetWindowLong (windowHandle, GWL_EXSTYLE);
            windowStyle |= WS_CLIPCHILDREN;
            SetWindowLong (windowHandle, GWL_EXSTYLE, windowStyle);

            /* We create a window data structure to store information in... */
            windowData = newWindowData (); /* Constructor. */
            /* And we store it in our window's user data pointer. */
            SetWindowLongPtr (windowHandle, GWLP_USERDATA, (LONG_PTR)windowData);

            /* Load our bitmaps: */
            backdrop        = getControlBitmap("backdrop", "backdrop");
            wbClose         = getControlBitmap("windowbuttons", "windowbuttonsClose");
            wbMinimize      = getControlBitmap("windowbuttons", "windowbuttonsMinimize");
            wbMaximize      = getControlBitmap("windowbuttons", "windowbuttonsMaximize");
            wbCloseHover    = getControlBitmap("windowbuttons", "windowbuttonsCloseHover");
            wbMinimizeHover = getControlBitmap("windowbuttons", "windowbuttonsMinimizeHover");
            wbMaximizeHover = getControlBitmap("windowbuttons", "windowbuttonsMaximizeHover");

            break;
        }
        case WM_DESTROY:
        /* Destroy right after create, how lovely... */
        /* Clean up any remaining allocations: */
        {
            windowData = (struct windowdata *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);
            /* We deconstruct our windowdata structure: */
            deleteWindowData (windowData);

            break;
        }
        case WM_USER:
        /* This is where we establish a procedure to forward messages to. */
        {
            forwardTo = (windowProcPointer)wParam;
            /* Send them the creation message to simulate normal windowing. */
            forwardTo (windowHandle, WM_CREATE, 0, 0);

            /* Make sure the window positions and dimensions are correct. */
            SendMessage (windowHandle, WM_SIZE, 0, 0);

            return 0;
        }
        case WM_SIZE:
        {
            if (lParam == 0) break;

            windowData = (struct windowdata *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            if (GetWindowLong (windowHandle, GWL_STYLE) & WS_MAXIMIZE)
            {
                SetWindowLong (windowHandle, GWL_STYLE,
                GetWindowLong (windowHandle, GWL_STYLE) | WS_OVERLAPPEDWINDOW);
                SetWindowRgn (windowHandle, NULL, 1);

                windowData->maximized = 1;

                RedrawWindow (windowHandle, NULL, NULL, RDW_INVALIDATE);
            }
            else
            {
                /* Get window dimensions: */
                GetWindowRect (windowHandle, &windowRect);

                /* Set round region. */
                SetWindowLong (windowHandle, GWL_STYLE,
                GetWindowLong (windowHandle, GWL_STYLE) ^ WS_OVERLAPPEDWINDOW);
                windowRegion = CreateRoundRectRgn(0, 0, (windowRect.right - windowRect.left), (windowRect.bottom - windowRect.top), 10, 10);
                SetWindowRgn (windowHandle, windowRegion, 1);

                windowData->maximized = 0;
                RedrawWindow (windowHandle, NULL, NULL, RDW_INVALIDATE);
            }

            break;
        }
        case WM_GETMINMAXINFO:
        {
            maxInfo = (MINMAXINFO *)lParam;
            maxInfo->ptMinTrackSize.y = 50;
            maxInfo->ptMinTrackSize.x = 150;

            break;
        }
        case WM_ERASEBKGND:
        /* When we want to repaint the window, this clears it. We don't want to do that. */
        {
            /* We leave the contents so that we can just paint over it to avoid flickering. */
            return 1;
        }
        case WM_SETCURSOR:
        /* The cursor icon changes several times: */
        /* This happens when the cursor is going to be set, so we intervene. */
        {
                switch (cursorType)
                {
                    case CURSOR_SIZENS:
                        SetCursor (LoadCursor(0, IDC_SIZENS));
                        break;
                    case CURSOR_SIZEWE:
                        SetCursor (LoadCursor(0, IDC_SIZEWE));
                        break;
                    case CURSOR_SIZENESW:
                        SetCursor (LoadCursor(0, IDC_SIZENESW));
                        break;
                    case CURSOR_SIZENWSE:
                        SetCursor (LoadCursor(0, IDC_SIZENWSE));
                        break;
                    case CURSOR_ARROW:
                        SetCursor (LoadCursor(0, IDC_ARROW));
                        break;
                    case CURSOR_HAND:
                        SetCursor (LoadCursor(0, IDC_HAND));
                        break;
                    case CURSOR_SIZEALL:
                        SetCursor (LoadCursor(0, IDC_SIZEALL));
                        break;
                }

                /* We don't want to return the default procedure, so finish up: */
                return 0;
        }
        case WM_MOUSEMOVE:
        /* Check for mouse positions like resizing, and the window buttons. */
        {
            /* Get the dimensions of the window: */
            GetClientRect (windowHandle, &windowRect);
            windowWidth = windowRect.right - windowRect.left; /* Save us taking up space. */
            windowHeight = windowRect.bottom - windowRect.top; /* Again, this is about code space. */

            /* Make our calculations a bit less confusing. */
            yPosition = HIWORD (lParam);
            xPosition = LOWORD (lParam);

            windowData = (struct windowdata *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            if (windowData->maximized == 1)
            {
                cursorType = CURSOR_ARROW;
                return DefWindowProc (windowHandle, theMessage, wParam, lParam);
                break;
            }

            if ((xPosition > buttonsLeft) && (xPosition < buttonsRight) &&
                (yPosition > buttonsTop) && (yPosition < buttonsBottom))
            {
                cursorType = CURSOR_HAND;
                changeType = -1;
                windowData->closeButtonHover = 1;

                RedrawWindow (windowHandle, NULL, NULL, RDW_INVALIDATE);
                break;
            }
            else if ((xPosition > buttonsLeft - 20) && (xPosition < buttonsRight - 20) &&
                (yPosition > buttonsTop)  && (yPosition < buttonsBottom))
            {
                cursorType = CURSOR_HAND;
                changeType = -1;
                windowData->maximizeButtonHover = 1;

                RedrawWindow (windowHandle, NULL, NULL, RDW_INVALIDATE);
                break;
            }
            else if ((xPosition > buttonsLeft - 40) && (xPosition < buttonsRight - 40) &&
                (yPosition > buttonsTop)  && (yPosition < buttonsBottom))
            {
                cursorType = CURSOR_HAND;
                changeType = -1;
                windowData->minimizeButtonHover = 1;

                RedrawWindow (windowHandle, NULL, NULL, RDW_INVALIDATE);
                break;
            }

            if ((windowData->closeButtonHover == 1) ||
            (windowData->minimizeButtonHover == 1) ||
            (windowData->maximizeButtonHover == 1))
            {
                windowData->closeButtonHover = 0;
                windowData->minimizeButtonHover = 0;
                windowData->maximizeButtonHover = 0;
                RedrawWindow (windowHandle, NULL, NULL, RDW_INVALIDATE);
            }

            /* Here we establish what cursor icon is going to be shown: */
            /* First, the corners... */
            if ((xPosition <= EX_BORDER_WIDTH) && (yPosition <= EX_BORDER_HEIGHT))
            /* Mouse is at the top left. */
            {
                cursorType = CURSOR_SIZENWSE;
                changeType = HTTOPLEFT;
            }
            else if ((xPosition >= (windowWidth - EX_BORDER_WIDTH)) && (yPosition <= (EX_BORDER_HEIGHT)))
            /* Mouse is at the top right. */
            {
                cursorType = CURSOR_SIZENESW;
                changeType = HTTOPRIGHT;
            }
            else if ((xPosition <= EX_BORDER_WIDTH) && (yPosition >= (windowHeight - EX_BORDER_HEIGHT)))
            /* Mouse is at the bottom left. */
            {
                cursorType = CURSOR_SIZENESW;
                changeType = HTBOTTOMLEFT;
            }
            else if ((xPosition >= (windowWidth - EX_BORDER_WIDTH)) && (yPosition >= (windowHeight - EX_BORDER_HEIGHT)))
            /* Mouse is at the bottom right. */
            {
                cursorType = CURSOR_SIZENWSE;
                changeType = HTBOTTOMRIGHT;
            }
            /* That's the end of the corners. */
            /* Now, the straight edges...*/
            else if (xPosition <= EX_BORDER_WIDTH)
            /* Mouse is on the left. */
            {
                cursorType = CURSOR_SIZEWE;
                changeType = HTLEFT;
            }
            else if (xPosition >= (windowWidth - EX_BORDER_WIDTH))
            /* Mouse is on the right. */
            {
                cursorType = CURSOR_SIZEWE;
                changeType = HTRIGHT;
            }
            else if (yPosition <= EX_BORDER_HEIGHT)
            /* Mouse is at the top. */
            {
                cursorType = CURSOR_SIZENS;
                changeType = HTTOP;
            }
            else if (yPosition >= (windowHeight - EX_BORDER_HEIGHT))
            /* Mouse is on the bottom. */
            {
                cursorType = CURSOR_SIZENS;
                changeType = HTBOTTOM;
            }
            else
            /* That's the last of the positions where a mouse can resize the window. */
            /* Mouse is not in a resize area. */
            {
                cursorType = CURSOR_ARROW;
                changeType = HTCAPTION;
            }

            break;
        }

        case WM_LBUTTONDOWN:
        /* Check for mouse clicks on certain areas. */
        {
            /* Get window dimensions: */
            GetWindowRect (windowHandle, &windowRect);

            /* These are for the positions of our control buttons. */
            buttonsLeft = windowRect.right - windowRect.left - 20;
            buttonsTop = 10;
            buttonsRight = buttonsLeft + 10;
            buttonsBottom = buttonsTop + 10;

            xPosition = LOWORD(lParam);
            yPosition = HIWORD(lParam);

            if ((xPosition > buttonsLeft) && (xPosition < buttonsRight) &&
                (yPosition > buttonsTop)  && (yPosition < buttonsBottom))
            /* The close button. */
            {
                forwardTo (windowHandle, WM_CLOSE, 0, 0);
            }
            else if ((xPosition > buttonsLeft - 20) && (xPosition < buttonsRight - 20) &&
                (yPosition > buttonsTop)  && (yPosition < buttonsBottom))
            /* The maximize button. */
            {
                DWORD dwStyle = GetWindowLong (windowHandle, GWL_STYLE);
                if (dwStyle & WS_MAXIMIZE)
                    ShowWindow (windowHandle, SW_NORMAL);
                else
                    ShowWindow (windowHandle, SW_MAXIMIZE);
            }
            else if ((xPosition > buttonsLeft - 40) && (xPosition < buttonsRight - 40) &&
                (yPosition > buttonsTop)  && (yPosition < buttonsBottom))
            /* The minimize button. */
            {
                ShowWindow (windowHandle, SW_MINIMIZE);
            }
            else
            /* The user is dragging the window with the mouse: */
            {
                if (changeType > -1)
                SendMessage (windowHandle, WM_NCLBUTTONDOWN, changeType, 0);
            }

            break;
        }
        case WM_PAINT:
        {
            /* Get the dimensions of the window: */
            GetWindowRect (windowHandle, &windowRect);
            windowWidth = windowRect.right - windowRect.left; /* Save us taking up space. */
            windowHeight = windowRect.bottom - windowRect.top; /* Again, this is about code space. */

            /* Establish control button coordinates: */
            buttonsLeft = windowRect.right - windowRect.left - 20;
            buttonsTop = 10;
            buttonsRight = buttonsLeft + 10;
            buttonsBottom = buttonsTop + 10;

            windowData = (struct windowdata *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            /* Create a DC object of our window: */
            windowDC = BeginPaint (windowHandle, &paintStruct);

            /* Create a gray pen to use for the border. */
            newPen = CreatePen (PS_SOLID, 1, RGB (190, 190, 190));

            /* Paint a white background: */
            newBrush = CreateSolidBrush (RGB (255, 255, 255));

            if (windowData->maximized == 0)
            {
                drawRoundRect (windowDC, 0, 0, windowWidth - 1, windowHeight - 1, 10, 10, newBrush, newPen);
            }
            else
            {
                drawRect (windowDC, 0, 0, windowWidth - 1, windowHeight - 1, newBrush, newPen);
            }

            DeleteObject (newBrush);

            /* Paint the bitmap: */
            GetObject (backdrop, sizeof bitmapInfo, &bitmapInfo); /* Get dimensions. */
            drawNormalBitmap (windowDC, backdrop, windowWidth - bitmapInfo.bmWidth - 2, 2);

            if (windowData->maximized == 0)
            {
                if (windowData->closeButtonHover == 0)
                {
                    GetObject (wbClose, sizeof(bitmapInfo), &bitmapInfo);
                    drawTransparentBitmap(windowDC, wbClose,
                    windowRect.right - windowRect.left - bitmapInfo.bmWidth - 10,
                    10, 0x00FF00FF);
                }
                else
                {
                    GetObject (wbCloseHover, sizeof(bitmapInfo), &bitmapInfo);
                    drawTransparentBitmap(windowDC, wbCloseHover,
                    windowRect.right - windowRect.left - bitmapInfo.bmWidth - 10,
                    10,
                    0x00FF00FF);
                }

                if (windowData->maximizeButtonHover == 0)
                {
                    GetObject (wbMaximize, sizeof(bitmapInfo), &bitmapInfo);
                    drawTransparentBitmap(windowDC, wbMaximize,
                    windowRect.right - windowRect.left - (bitmapInfo.bmWidth * 2) - (10 * 2),
                    10,
                    0x00FF00FF);
                }
                else
                {
                    GetObject (wbMaximizeHover, sizeof(bitmapInfo), &bitmapInfo);
                    drawTransparentBitmap(windowDC, wbMaximizeHover,
                    windowRect.right - windowRect.left - (bitmapInfo.bmWidth * 2) - (10 * 2),
                    10,
                    0x00FF00FF);
                }

                if (windowData->minimizeButtonHover == 0)
                {
                    GetObject (wbMinimize, sizeof(bitmapInfo), &bitmapInfo);
                    drawTransparentBitmap(windowDC, wbMinimize,
                    windowRect.right - windowRect.left - (bitmapInfo.bmWidth * 3) - (10 * 3),
                    10,
                    0x00FF00FF);
                }
                else
                {
                    GetObject (wbMinimizeHover, sizeof(bitmapInfo), &bitmapInfo);
                    drawTransparentBitmap( windowDC, wbMinimizeHover,
                    windowRect.right - windowRect.left - (bitmapInfo.bmWidth * 3) - (10 * 3),
                    10,
                    0x00FF00FF);
                }
            }

            /* Draw our border over it: */
            /* Bit of a shadow effect: */
            newBrush = GetStockObject(NULL_BRUSH);
            if (windowData->maximized == 0) drawRoundRect (windowDC, -1, -1, windowWidth - 2, windowHeight - 2, 10, 10, newBrush, newPen);
            DeleteObject (newBrush);

            /* Change the pen colour: */
            DeleteObject (newPen);
            newPen = CreatePen(PS_SOLID, 1, RGB (150, 150, 150));

            newBrush = GetStockObject(NULL_BRUSH);
            if (windowData->maximized == 0) drawRoundRect (windowDC, 0, 0, windowWidth - 1, windowHeight - 1, 10, 10, newBrush, newPen);
            DeleteObject (newBrush);

            /* Delete our pen. */
            DeleteObject (newPen);

            /* Delete the DC object: */
            EndPaint (windowHandle, &paintStruct);

            break;
        }
    }

    if (forwardTo != NULL)
    /* If we have been given a procedure to forward messages to: */
        return forwardTo (windowHandle, theMessage, wParam, lParam);
    else
    /* Just return the default procedure: */
        return DefWindowProc (windowHandle, theMessage, wParam, lParam);
}


/* ------------------------------------------------------------------- */
/* Functions for construction/deconstruction of windowdata structures: */
/* ------------------------------------------------------------------- */

/* Constructor */
struct windowdata *newWindowData ()
{
    struct windowdata *newWD;

    newWD = malloc(sizeof *newWD);
    newWD->closeButtonHover = 0;
    newWD->minimizeButtonHover = 0;
    newWD->maximizeButtonHover = 0;
    newWD->maximized = 0;

    return newWD;
}

/* Deconstructor */
void deleteWindowData (struct windowdata *windowData)
/* We need this function in case we make any allocations in the structure. */
{
    free (windowData);
}
