            GetWindowRect (windowHandle, &windowRect);
            hdc = BeginPaint(windowHandle, &ps);

            hdcMem = CreateCompatibleDC(hdc);

            if ((LONG)GetWindowLong(windowHandle, GWL_USERDATA) == 0)
            {
                hbmOld = SelectObject(hdcMem, getControlBitmap("button", "buttonMiddle"));
                GetObject(getControlBitmap("button", "buttonMiddle"), sizeof(bm), &bm);
                StretchBlt (hdc, 0, 0, windowRect.right - windowRect.left, BUTTON_HEIGHT,
                hdcMem, 0, 0, 10, BUTTON_HEIGHT, SRCCOPY);

                hbmOld = SelectObject(hdcMem, getControlBitmap("button", "buttonLeft"));
                GetObject(getControlBitmap("button", "buttonLeft"), sizeof(bm), &bm);
                BitBlt(hdc, 0, 0, bm.bmWidth, bm.bmHeight, hdcMem, 0, 0, SRCCOPY);

                hbmOld = SelectObject(hdcMem, getControlBitmap("button", "buttonRight"));
                GetObject(getControlBitmap("button", "buttonRight"), sizeof(bm), &bm);
                BitBlt(hdc, windowRect.right - windowRect.left - bm.bmWidth, 0, bm.bmWidth, bm.bmHeight, hdcMem, 0, 0, SRCCOPY);
            }
            else
            {
                hbmOld = SelectObject(hdcMem, getControlBitmap("button", "buttonMiddlePressed"));
                GetObject(getControlBitmap("button", "buttonMiddlePressed"), sizeof(bm), &bm);
                StretchBlt (hdc, 0, 0, windowRect.right - windowRect.left, BUTTON_HEIGHT,
                hdcMem, 0, 0, 10, BUTTON_HEIGHT, SRCCOPY);

                hbmOld = SelectObject(hdcMem, getControlBitmap("button", "buttonLeftPressed"));
                GetObject(getControlBitmap("button", "buttonLeftPressed"), sizeof(bm), &bm);
                BitBlt(hdc, 0, 0, bm.bmWidth, bm.bmHeight, hdcMem, 0, 0, SRCCOPY);

                hbmOld = SelectObject(hdcMem, getControlBitmap("button", "buttonRightPressed"));
                GetObject(getControlBitmap("button", "buttonRightPressed"), sizeof(bm), &bm);
                BitBlt(hdc, windowRect.right - windowRect.left - bm.bmWidth, 0, bm.bmWidth, bm.bmHeight, hdcMem, 0, 0, SRCCOPY);
            }

            HFONT oldFont=(HFONT)SelectObject(hdc, getMainFont ());
            SetBkMode(hdc,TRANSPARENT);
			SetTextColor(hdc,RGB(255,255,255));

            LPRECT prc = malloc(sizeof *prc);
            prc->left = 0;
            prc->top = 0;
            prc->right = windowRect.right - windowRect.left;
            prc->bottom = BUTTON_HEIGHT - 4;

            GetWindowText(windowHandle, caption, 511);
            DrawText(hdc, caption, -1, prc, DT_SINGLELINE | DT_CENTER | DT_VCENTER);

            SelectObject(hdc, oldFont);

            DeleteDC(hdcMem);
            EndPaint(windowHandle, &ps);

            free(prc);