#include <windows.h>

BOOL WINAPI DllMain (HINSTANCE, DWORD, LPVOID);
int registerClasses (void);
