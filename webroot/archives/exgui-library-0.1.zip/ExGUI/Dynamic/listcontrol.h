#include <windows.h>

struct listitem
{
    void *data;
};

LRESULT CALLBACK listWindowProcedure (HWND, UINT, WPARAM, LPARAM);
