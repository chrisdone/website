#include "staticcontrol.h"
#include "theme.h"
#include <windows.h>

LRESULT CALLBACK staticWindowProcedure (HWND windowHandle, UINT theMessage, WPARAM wParam, LPARAM lParam)
{
    PAINTSTRUCT paintStruct;
    HDC windowDC;
    RECT windowRect;
    static char captionText[513];

    switch (theMessage)
    {
        case WM_CREATE:
        {

            break;
        }
        case WM_PAINT:
        {
            GetWindowRect (windowHandle, &windowRect);

            windowDC = BeginPaint (windowHandle, &paintStruct);

            SetTextColor (windowDC, RGB (100, 100, 100));

            GetWindowText (windowHandle, &captionText, 512);
            drawText (windowDC, captionText,
            0, 0,
            windowRect.right - windowRect.left,
            windowRect.bottom - windowRect.top,
            getMainFont (),
            0);

            EndPaint (windowHandle, &paintStruct);

            break;
        }
    }

    return DefWindowProc (windowHandle, theMessage, wParam, lParam);
}
