#include <windows.h>

LRESULT CALLBACK frameWindowProcedure (HWND, UINT, WPARAM, LPARAM);
