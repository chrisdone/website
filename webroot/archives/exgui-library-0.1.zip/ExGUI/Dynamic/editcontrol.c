#include "editcontrol.h"
#include "theme.h"
#include <windows.h>
#include <richedit.h>

LRESULT CALLBACK editWindowProcedure (HWND windowHandle, UINT theMessage, WPARAM wParam, LPARAM lParam)
{
    RECT windowRect;
    char editText[513];

    switch (theMessage)
    {
        case WM_ERASEBKGND:
        {
            return 0;
        }
        case EM_SETSEL:
        {
            break;
        }
        case WM_SETTEXT:
        {
            char *cpyText = lParam;
            int nCpyText = strlen(cpyText);

            CHARFORMAT cfSysText;
            ZeroMemory(&cfSysText, sizeof(CHARFORMAT));
            cfSysText.cbSize = sizeof(CHARFORMAT);
            cfSysText.dwMask = CFM_COLOR;
            cfSysText.dwEffects = CFE_BOLD;
            cfSysText.crTextColor = RGB (100, 100, 100);
            strcpy(cfSysText.szFaceName, "Verdana");

            struct edithandleinfo *editInfo = (struct edithandleinfo *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);
            HWND editHandle = editInfo->handle;

            int nLength = GetWindowTextLength(editHandle);
            SendMessage(editHandle, EM_SETSEL, nLength, nLength);
            SendMessage(editHandle, EM_REPLACESEL, FALSE, (LPARAM)cpyText);
            SendMessage(editHandle, EM_SETSEL, nLength, nLength + nCpyText);
            SendMessage(editHandle, EM_SETCHARFORMAT, SCF_SELECTION, (LPARAM)&cfSysText);
            SendMessage(editHandle, EM_SETSEL, nLength + nCpyText, nLength + nCpyText);

            return 0;
        }
        case WM_PAINT:
        {
            struct edithandleinfo *editInfo = (struct edithandleinfo *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            if (!editInfo->withBorder) break;

            GetWindowRect (windowHandle, &windowRect);
            int windowWidth = windowRect.right - windowRect.left; /* Save us taking up space. */
            int windowHeight = windowRect.bottom - windowRect.top; /* Again, this is about code space. */
            /* Create a DC object of our window: */

            PAINTSTRUCT paintStruct;
            HDC windowDC = BeginPaint (windowHandle, &paintStruct);

            /* Create a gray pen to use for the border. */
            HPEN newPen = CreatePen (PS_SOLID, 1, RGB (190, 190, 190));

            /* Paint a white background: */
            HBRUSH newBrush = CreateSolidBrush (RGB (255, 255, 255));

            drawRect (windowDC, 0, 0, windowWidth - 2, windowHeight - 2, newBrush, newPen);

            DeleteObject (newBrush);

            /* Delete our pen. */
            DeleteObject (newPen);

            /* Delete the DC object: */
            EndPaint (windowHandle, &paintStruct);
            break;
        }
        case WM_SIZE:
        {
            struct edithandleinfo *editInfo = (struct edithandleinfo *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);
            HWND editHandle = editInfo->handle;

            GetWindowRect (windowHandle, &windowRect);

            SetWindowPos (editHandle, NULL,
            0, 0,
            (windowRect.right - windowRect.left) - 1,
            (windowRect.bottom - windowRect.top) - 1,
            SWP_NOMOVE);


            break;
        }
        case WM_CREATE:
        {
            /* Make sure the window style is transparent. */
            SetWindowLong (windowHandle, GWL_EXSTYLE,
            GetWindowLong (windowHandle, GWL_EXSTYLE) + WS_EX_TRANSPARENT);

            GetWindowRect (windowHandle, &windowRect);
            GetWindowText (windowHandle, editText, 512);

            int readOnly = 0;

            if (GetWindowLong (windowHandle, GWL_STYLE) & ES_READONLY)
            {
                readOnly = ES_READONLY;
            }

            // create richedit control
            HWND editHandle = CreateWindowEx(WS_EX_TRANSPARENT, RICHEDIT_CLASS, "",
            WS_CHILD | WS_VISIBLE | ES_MULTILINE | readOnly | ES_AUTOVSCROLL,
            1, 1, windowRect.right - windowRect.left - 2,
            windowRect.bottom - windowRect.top - 2, windowHandle, NULL,
            (HINSTANCE)GetWindowLong (windowHandle, GWL_HINSTANCE), NULL);

            struct edithandleinfo *editInfo = malloc(sizeof *editInfo);
            editInfo->withBorder = 0;
            editInfo->handle = editHandle;

            if (GetWindowLong (windowHandle, GWL_STYLE) & WS_BORDER)
            {
                SetWindowLong (windowHandle, GWL_STYLE, GetWindowLong (windowHandle, GWL_STYLE) ^ WS_BORDER);
                editInfo->withBorder = 1;
            }

            SetWindowLongPtr (windowHandle, GWLP_USERDATA, editInfo);

            SendMessage (editHandle, WM_SETFONT, (WPARAM)*getMainFont (), (LPARAM)0);
            SendMessage (editHandle, EM_AUTOURLDETECT, (WPARAM)TRUE, (LPARAM)0);

            return 0;
        }
    }

    return DefWindowProc (windowHandle, theMessage, wParam, lParam);
}
