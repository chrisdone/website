#include "listcontrol.h"
#include "theme.h"
#include <windows.h>

LRESULT CALLBACK listWindowProcedure (HWND windowHandle, UINT theMessage, WPARAM wParam, LPARAM lParam)
{
    BITMAP bitmapInfo;
    PAINTSTRUCT paintStruct;
    HDC drawingContext;
    HDC contextMemory;
    HBITMAP oldObject;
    static HBITMAP listBitmap = NULL;
    struct list *simpleList;
    struct list *newItem;
    char *addString;
    int deleteString;

    switch (theMessage)
    {
        case WM_CREATE:
        {
            simpleList = newList ();
            SetWindowLongPtr (windowHandle, GWLP_USERDATA, (LONG_PTR)simpleList);
            listBitmap = getControlBitmap ("list", "list");

            break;
        }
        case WM_ERASEBKGND:
        {
            return 0;
        }
        case WM_PAINT:
        {
            if (listBitmap == NULL)
            /* Nothing to draw. */
                break;

            /* Get the list. */
            simpleList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            PAINTSTRUCT paintStruct;
            HDC windowDC = BeginPaint (windowHandle, &paintStruct);
			SetTextColor (windowDC, RGB (100, 100, 100));

            /* Get window dimensions. */
            RECT windowRect;
            GetWindowRect (windowHandle, &windowRect);
            int windowHeight = windowRect.bottom - windowRect.top;

            /* Draw each list item until we reach the end of the list box window. */
            BITMAP bitmapInfo;
            GetObject (listBitmap, sizeof bitmapInfo, &bitmapInfo);
            int yPosition = 8;
            int xPosition = 8;
            int textX;
            for ( ;simpleList /* && (yPosition < windowHeight) */;
                (simpleList = simpleList->next, yPosition += bitmapInfo.bmHeight + 10))
            {
                if (simpleList->data)
                {
                    drawTransparentBitmap (windowDC, listBitmap,
                        xPosition, yPosition, 0xFF00FF);

                    textX = xPosition + bitmapInfo.bmWidth + xPosition;
                    drawText (windowDC, simpleList->data,
                        textX,
                        yPosition,
                        (windowRect.right - windowRect.left) - textX,
                        yPosition + bitmapInfo.bmHeight,
                        getMainFont (),
                        0);
                }
            }

            EndPaint (windowHandle, &paintStruct);

            break;
        }
        case LB_ADDSTRING:
        {
            addString = malloc(strlen((char *)lParam) + 1);

            strcpy(addString, (char *)lParam);

            simpleList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            addToList(simpleList, addString);

            RedrawWindow(windowHandle, NULL, NULL, RDW_INVALIDATE);

            break;
        }
        case LB_DELETESTRING:
        {
            deleteString = (int)wParam;

            simpleList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            newItem = removeFromList (simpleList, deleteString, free);
            simpleList = newItem;

            SetWindowLongPtr (windowHandle, GWLP_USERDATA, (LONG_PTR)simpleList);

            RedrawWindow(windowHandle, NULL, NULL, RDW_INVALIDATE);

            break;
        }
        default: return DefWindowProc (windowHandle, theMessage, wParam, lParam);
    }

    return 0;
}
