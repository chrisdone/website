#define WINVER 0x500 /* For use with AlphaBlend. */

/* Required for tab information: */
#include "tabcontrol.h"

/* Required for font and bitmap functions: */
#include "theme.h"

/* Required for lists: */
#include "list.h"

/* System libraries. */
#include <windows.h>
#include <wingdi.h> /* For use with AlphaBlend. */

LRESULT CALLBACK tabWindowProcedure (HWND windowHandle, UINT theMessage, WPARAM wParam, LPARAM lParam)
{
    /* Painting objects. */
    HDC windowDC;
    PAINTSTRUCT paintStruct;
    BITMAP bitmapInfo;
    HFONT oldFont;

    /* Used for window coordinates and dimensions.  */
    RECT windowRect;
    int windowWidth;
    int windowHeight;
    int drawPosition;
    int maxDraw;
    int tabDraw;
    int textPosition;
    SIZE stringSize;
    int tabLeftWidth;
    int tabRightWidth;

    /* Tab add/remove objects: */
    const char *    addString;
    int             deleteString;

    /* Tab list objets. */
    struct list *tabList;
    struct list *newItem;
    struct list *tempList;
    struct tab  *tabToAdd;
    struct tab  *theTab;
    int dontPaintBitmaps = 0;

    /* Various iteration integers. */
    int     count;
    int     tabIndex;
    int     arrIndex;
    int     position;

    /* Used as a pointer for storing the tab indexes in. */
    int *   selectedItems;

    /* Static cursor objects. */
    static HCURSOR  newCursor;
    static int      cursorSet = 0;

    /* Static bitmaps: */
    /* We only have to load these once. */
    static HBITMAP tabLeft          = NULL;
    static HBITMAP tabMiddle        = NULL;
    static HBITMAP tabRight         = NULL;
    static HBITMAP tabPressedLeft   = NULL;
    static HBITMAP tabPressedMiddle = NULL;
    static HBITMAP tabPressedRight  = NULL;
    static HBITMAP tabHoverLeft     = NULL;
    static HBITMAP tabHoverMiddle   = NULL;
    static HBITMAP tabHoverRight    = NULL;
    HBITMAP *drawLeft;
    HBITMAP *drawMiddle;
    HBITMAP *drawRight;

    /* To check the mouse is still in the window. */
    static BOOL fInWindow = FALSE;
    TRACKMOUSEEVENT tme;

    switch (theMessage)
    {
        case WM_CREATE:
        /* The window has been created: */
        {
            /* Create our tab list. */
            tabList = newList ();
            /* Store it in the user data pointer of our window. */
            SetWindowLongPtr (windowHandle, GWLP_USERDATA, (LONG_PTR)tabList);

            /* Make sure the window style is transparent. */
            SetWindowLong (windowHandle, GWL_EXSTYLE,
            GetWindowLong (windowHandle, GWL_EXSTYLE) + WS_EX_TRANSPARENT);

            /* Load our bitmaps. */
            tabLeft             = getControlBitmap ("tab","tabLeft");
            tabMiddle           = getControlBitmap ("tab", "tabMiddle");
            tabRight            = getControlBitmap ("tab", "tabRight");
            tabPressedLeft      = getControlBitmap ("tab", "tabPressedLeft");
            tabPressedMiddle    = getControlBitmap ("tab", "tabPressedMiddle");
            tabPressedRight     = getControlBitmap ("tab", "tabPressedRight");
            tabHoverLeft        = getControlBitmap ("tab", "tabHoverLeft");
            tabHoverMiddle      = getControlBitmap ("tab", "tabHoverMiddle");
            tabHoverRight       = getControlBitmap ("tab", "tabHoverRight");

            break;
        }
        case WM_SIZE:
        /* The window has been resized: */
        {
            /* Don't allow the tab to be sized past its height. */
            GetWindowRect (windowHandle, &windowRect);
            if (HIWORD(lParam) > TABMENU_HEIGHT)
            SetWindowPos (windowHandle, NULL, windowRect.left, windowRect.top,
            LOWORD(lParam), TABMENU_HEIGHT, SWP_NOMOVE);

            break;
        }
        case WM_ERASEBKGND:
        {
            /* Don't clear the DC when we repaint. */
            return 1;
        }
        case WM_PAINT:
        /* The window needs to be painted. */
        {
            /* Get the window dimensions. */
            GetWindowRect (windowHandle, &windowRect);
            windowWidth = windowRect.right - windowRect.left; /* Save us taking up space. */
            windowHeight = windowRect.bottom - windowRect.top; /* Again, this is about code space. */

            /* Get the DC. */
            windowDC = BeginPaint (windowHandle, &paintStruct);

            /* Draw the borders, making the purple bits transparent. */
            GetObject (tabRight, sizeof bitmapInfo, &bitmapInfo);
            drawTransparentBitmap (windowDC, tabLeft, 0, 0, 0xFF00FF);
            drawTransparentBitmap (windowDC, tabRight,
            windowWidth - bitmapInfo.bmWidth, 0, 0xFF00FF);

            /* Draw the middle part of the menu. */
            GetObject (tabMiddle, sizeof bitmapInfo, &bitmapInfo);
            maxDraw = windowWidth - (bitmapInfo.bmWidth * 2);
            for (drawPosition = bitmapInfo.bmWidth; ; drawPosition += bitmapInfo.bmWidth)
            {
                /* Make sure we don't draw over the right border. */
                if (drawPosition > maxDraw) drawPosition = maxDraw;
                drawTransparentBitmap (windowDC, tabMiddle, drawPosition, 0, 0xFF00FF);
                if (drawPosition == maxDraw) break;
            }

            /* Get the tab list from our window:  */
            tabList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            SetTextColor (windowDC, RGB (255, 255, 255));

            oldFont = SelectObject (windowDC, *getMainFont ());

            /* It's time to draw the actual tabs: */
            drawPosition = TAB_SPACING;
            for (tempList = tabList; tempList; tempList = tempList->next)
            {
                dontPaintBitmaps = 0;

                if (tempList->data)
                {
                    theTab = tempList->data;

                    textPosition = drawPosition;
                    int tabWidth = drawPosition;

                    if (theTab->isPressed)
                    {
                        drawLeft = tabPressedLeft;
                        drawMiddle = tabPressedMiddle;
                        drawRight = tabPressedRight;
                    }
                    else if (theTab->isHighlighted)
                    {
                        drawLeft = tabHoverLeft;
                        drawMiddle = tabHoverMiddle;
                        drawRight = tabHoverRight;
                    }
                    else
                    {
                        drawLeft = tabPressedLeft;
                        drawMiddle = tabPressedMiddle;
                        drawRight = tabPressedRight;
                        dontPaintBitmaps = 1;
                    }

                    /* Get the width of the tab according to the caption string. */
                    GetTextExtentPoint32 (windowDC, theTab->caption,
                    strlen(theTab->caption) - 1, &stringSize);
                    /* This is the maximium times to draw the middle bitmap. */
                    maxDraw = (stringSize.cx / bitmapInfo.bmWidth) + 2;
                    /* If we've gone beyond the width of the tab menu, exit. */
                    if ((drawPosition + bitmapInfo.bmWidth + (maxDraw * bitmapInfo.bmWidth)) > windowWidth - TAB_SPACING)
                        break;

                    /* Draw left bitmap. */
                    GetObject (drawLeft, sizeof bitmapInfo, &bitmapInfo);
                    if (!dontPaintBitmaps)
                    {
                        drawTransparentBitmap (windowDC, drawLeft,
                        drawPosition, 0, 0xFF00FF);

                    }
                    drawPosition += bitmapInfo.bmWidth;
                    tabLeftWidth = bitmapInfo.bmWidth;

                    GetObject (drawRight, sizeof bitmapInfo, &bitmapInfo);
                    tabRightWidth = bitmapInfo.bmWidth;

                    /* Draw middle bitmaps. */
                    GetObject (drawMiddle, sizeof bitmapInfo, &bitmapInfo);
                    for (tabDraw = 0; tabDraw < maxDraw; tabDraw ++)
                    {
                        if ((tabDraw * bitmapInfo.bmWidth) > ((maxDraw * bitmapInfo.bmWidth) - (tabLeftWidth + tabRightWidth)))
                        {
                            drawPosition -= bitmapInfo.bmWidth;
                        }
                        if (!dontPaintBitmaps)
                        {
                            drawTransparentBitmap (windowDC, drawMiddle,
                            drawPosition, 0, 0xFF00FF);
                        }
                        drawPosition += bitmapInfo.bmWidth;
                    }

                    /* Draw right bitmaps. */
                    GetObject (drawRight, sizeof bitmapInfo, &bitmapInfo);
                    if (!dontPaintBitmaps)
                    {
                        drawTransparentBitmap (windowDC, drawRight,
                        drawPosition, 0, 0xFF00FF);
                    }
                    drawPosition += bitmapInfo.bmWidth + TAB_SPACING;
                    tabRightWidth = bitmapInfo.bmWidth;

                    theTab->tabWidth = drawPosition - tabWidth - TAB_SPACING;

                    drawText (windowDC, theTab->caption, textPosition, 0, drawPosition - TAB_SPACING,
                    bitmapInfo.bmHeight, getMainFont (), DT_CENTER);
                }
            }

            /* Select the old font. */
            SelectObject (windowDC, oldFont);

            /* Delete the DC. */
            EndPaint (windowHandle, &paintStruct);

            break;
        }
        case WM_SETCURSOR:
        /* A message to set the cursor icon. */
        {
            if (cursorSet != -1) SetCursor(newCursor);

            break;
        }
        case WM_MOUSELEAVE:
        /* The mouse has left the tab window. */
        {
            fInWindow = FALSE;

            /* Get the tab list. */
            tabList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            /* Make sure all the tabs are no longer highlighted. */
            tempList = tabList;
            while (tempList)
            {
                if (tempList->data)
                {
                    theTab = tempList->data;
                    theTab->isHighlighted = 0;
                }
                tempList = tempList->next;
            }

            /* Update the window. */
            RedrawWindow(windowHandle, NULL, NULL, RDW_INVALIDATE);

            break;
        }
        case WM_MOUSEMOVE:
        /* The user has moved the mouse. */
        {
            if (!fInWindow)
            {
               fInWindow = TRUE;
               tme.cbSize = sizeof(TRACKMOUSEEVENT);
               tme.dwFlags = TME_LEAVE;
               tme.hwndTrack =windowHandle;
               TrackMouseEvent(&tme);
            }

            tabList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            tempList = tabList;
            position = 10;
            int redraw = 0;

            int tabFound = 0;
            struct tab *f = NULL;

            while (tempList)
            {
                if (tempList->data)
                {
                    theTab = tempList->data;
                    if ((LOWORD(lParam) >= position) && (LOWORD(lParam) <= (position + theTab->tabWidth)))
                    {
                        if (theTab->isPressed == 0 || theTab->canBePressed)
                        {
                            /* If no previous tabs are highlighted: */
                            if (!tabFound)
                            {
                                if (cursorSet == 0 || cursorSet == 1)
                                {
                                    /* The mouse is over the button, change the mouse: */
                                    newCursor = LoadCursor(0, IDC_HAND);
                                    cursorSet = 2;
                                }
                                 tabFound = 1;
                                theTab->isHighlighted = 1;
                                f = theTab;
                            }
                            else
                            /* This means two tabs are set as highlighted: */
                            {
                                /* We must go through and set them as not highlighted: */
                                tempList = tabList;
                                while (tempList)
                                {
                                    if (tempList->data)
                                    {
                                        theTab = (struct tab *)tempList->data;

                                            theTab->isHighlighted = 0;
                                    }
                                    tempList = tempList->next;
                                }
                            }

                            redraw = 1;
                        }
                    }
                    else
                    {
                        theTab = tempList->data;
                        if (theTab->isHighlighted == 1)
                        {
                            theTab->isHighlighted = 0;
                            RedrawWindow(windowHandle, NULL, NULL, RDW_INVALIDATE);
                        }
                    }
                    position += theTab->tabWidth + TAB_SPACING;
                }
                tempList = tempList->next;
            }
            if (redraw)
            {
                RedrawWindow(windowHandle, NULL, NULL, RDW_INVALIDATE);
                return 0;
            }
            if (cursorSet == 0 || cursorSet == 2)
            {
                newCursor = LoadCursor(0, IDC_ARROW);
                cursorSet = 1;
            }

            break;
        }

        case WM_LBUTTONUP:
        /*---------------------------------------------------------------------*/
        /* The mouse button has been released.                                 */
        /*---------------------------------------------------------------------*/
        /* Message parameters:                                                 */
        /*---------------------------------------------------------------------*/
        /* lParam - Mouse position.                                            */
        /*---------------------------------------------------------------------*/
        {
            tabList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            tempList = tabList;
            position = 10;
            int tabIndex = 0;

            while (tempList)
            {
                if (tempList->data)
                {
                    theTab = (struct tab *)tempList->data;
                    if ((LOWORD(lParam) >= position) && (LOWORD(lParam) <= (position + theTab->tabWidth)))
                    {
                        /* The user clicked a tab, send the message: */
                        int toCancel = SendMessage (GetParent(windowHandle), WM_COMMAND,
                        MAKEWPARAM(GetWindowLong(windowHandle, GWL_ID), LBN_DBLCLK), tabIndex);

                        if (toCancel == 1) theTab->canBePressed = 1;
                        if (((!theTab->isPressed) && (!toCancel)) || theTab->canBePressed)
                        {
                            /* This will paint the tab in a 'pressed' state:   */
                            theTab->isPressed = !(theTab->isPressed);
                            theTab->isHighlighted = 0;
                            newCursor = LoadCursor(0, IDC_ARROW);
                            cursorSet = 1;
                            RedrawWindow(windowHandle, NULL, NULL, RDW_INVALIDATE);
                        }

                        return 0;
                    }
                    position += theTab->tabWidth + TAB_SPACING;
                }
                tempList = tempList->next;
                tabIndex++;
            }
            break;
        }

        case LB_SETCURSEL:
        {
            int tabNum = (int)wParam;
            int selectOrNot = (int)lParam;

            tabList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            tempList = tabList;

            tabIndex = 0;

            while (tempList)
            {
                if (tempList->data)
                {
                    theTab = tempList->data;
                    if (tabNum == tabIndex)
                    {
                        theTab->isPressed = selectOrNot;
                    }
                    tabIndex++;
                }
                tempList = tempList->next;
            }

            RedrawWindow(windowHandle, NULL, NULL, RDW_INVALIDATE);

            break;
        }

        case LB_GETSELCOUNT:
        /*---------------------------------------------------------------------*/
        /* A message asking for the number of tabs selected.                   */
        /*---------------------------------------------------------------------*/
        /* Message parameters:                                                 */
        /*---------------------------------------------------------------------*/
        /* Not used.                                                           */
        /*---------------------------------------------------------------------*/
        {
            tabList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);
            tempList = tabList;

            count = 0;

            while (tempList)
            {
                if (tempList->data)
                {
                    theTab = (struct tab *)tempList->data;
                    if (theTab->isPressed)
                    {
                        count++;
                    }
                }
                tempList = tempList->next;
            }

            return count;
        }

        case LB_GETSELITEMS:
        /*---------------------------------------------------------------------*/
        /* A message asking for the list indexes to be put into an array.      */
        /*---------------------------------------------------------------------*/
        /* Message parameters:                                                 */
        /*---------------------------------------------------------------------*/
        /* lParam - Integer array.                                             */
        /*---------------------------------------------------------------------*/
        {
            tabList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);
            tempList = tabList;

            tabIndex = 0;
            arrIndex = 0;
            selectedItems = (int *)lParam;

            while (tempList)
            {
                if (tempList->data)
                {
                    theTab = (struct tab *)tempList->data;
                    if (theTab->isPressed)
                    {
                        selectedItems[arrIndex] = tabIndex;
                        arrIndex ++;
                    }
                    tabIndex ++;
                }
                tempList = tempList->next;
            }

            break;
        }

        case LB_ADDSTRING:
        /*---------------------------------------------------------------------*/
        /* A message to add a new tab to the tab menu.                         */
        /*---------------------------------------------------------------------*/
        /* Message parameters:                                                 */
        /*---------------------------------------------------------------------*/
        /* lParam - New string to add.                                         */
        /*---------------------------------------------------------------------*/
        {
            addString = (char *)lParam;

            tabList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            tabToAdd = newTab (addString, TAB_NORMAL);

            addTabToList (tabList, tabToAdd);

            RedrawWindow (windowHandle, NULL, NULL, RDW_INVALIDATE);

            break;
        }

        /*---------------------------------------------------------------------*/
        /* A message to delete a tab item from the menu                        */
        /*---------------------------------------------------------------------*/
        /* Message parameters:                                                 */
        /*---------------------------------------------------------------------*/
        /* wParam - Tab index.                                                 */
        /*---------------------------------------------------------------------*/
        case LB_DELETESTRING:
        {
            deleteString = (int)wParam;

            tabList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            newItem = removeFromList (tabList, deleteString, deleteTab);
            tabList = newItem;

            SetWindowLongPtr (windowHandle, GWLP_USERDATA, (LONG_PTR)tabList);

            RedrawWindow (windowHandle, NULL, NULL, RDW_INVALIDATE);

            break;
        }
        default: return DefWindowProc (windowHandle, theMessage, wParam, lParam);
    }

    return 0;
}

/*------------------------------ addTabToList () ------------------------------*/
/*                                                                             */
/*  The add a new tab to a tab list.                                           */
/*                                                                             */
/*-------------------------------- Parameters ---------------------------------*/
/*                                                                             */
/*  theList    - List to add to.                                               */
/*  theTab     - New tab object.                                               */
/*------------------------------- Return value --------------------------------*/
/*                                                                             */
/*  None.                                                                      */
/*                                                                             */
/*-----------------------------------------------------------------------------*/
void addTabToList (struct list *theList, struct tab *theTab)
{
    struct list *newListItem;

    newListItem = addToList (theList, theTab);
}


/*--------------------------------- newTab () ---------------------------------*/
/*                                                                             */
/*  Create a new tab object.                                                   */
/*                                                                             */
/*-------------------------------- Parameters ---------------------------------*/
/*                                                                             */
/*  caption    - Caption of the tab.                                           */
/*  isPressed  - State of the tab.                                             */
/*------------------------------- Return value --------------------------------*/
/*                                                                             */
/*  struct tab *                                                               */
/*                                                                             */
/*-----------------------------------------------------------------------------*/
struct tab *newTab (const char *caption, int isPressed)
{
    struct tab *toCreate;

    toCreate = malloc (sizeof *toCreate);
    if (caption != NULL)
    {
        toCreate->caption = malloc (strlen(caption) + 1);
        strcpy(toCreate->caption, caption);
    }
    else
    {
        toCreate->caption = NULL;
    }
    toCreate->isPressed = isPressed;
    toCreate->isHighlighted = 0;
    toCreate->tabWidth = 0;
    toCreate->canBePressed = 0;

    return toCreate;
}


/*-------------------------------- deleteTab () -------------------------------*/
/*                                                                             */
/*  Delete a tab object                                                        */
/*                                                                             */
/*-------------------------------- Parameters ---------------------------------*/
/*                                                                             */
/*  voidToDelete - A void pointer to the tab..                                 */
/*                                                                             */
/*------------------------------- Return value --------------------------------*/
/*                                                                             */
/*  None.                                                                      */
/*                                                                             */
/*-----------------------------------------------------------------------------*/
void deleteTab (void *voidToDelete)
{
    struct tab *toDelete;
    toDelete = voidToDelete;
    if (toDelete->caption) free(toDelete->caption);
    free (toDelete);
}
