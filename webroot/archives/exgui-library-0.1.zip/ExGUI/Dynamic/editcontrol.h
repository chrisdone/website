#include <windows.h>

struct edithandleinfo
{
    HWND handle;
    int withBorder;
};

LRESULT CALLBACK editWindowProcedure (HWND windowHandle, UINT theMessage, WPARAM wParam, LPARAM lParam);
