/*------------------------------ tabcontrol.h ---------------------------------*/
/*                                                                             */
/*  This module handles all the operations for the tab menu control.           */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#include "list.h"
#include <windows.h>

#define TABMENU_HEIGHT 34
#define TAB_NORMAL 0
#define TAB_SPACING 10
#define TAB_WIDTH 3

LRESULT CALLBACK tabWindowProcedure (HWND, UINT, WPARAM, LPARAM);

struct tab
{
    char *caption;
    int isPressed;
    int isHighlighted;
    int tabWidth;
    int isDisabled;
    int canBePressed;
};

void addTabToList (struct list *, struct tab *);
struct tab *newTab (const char *, int);
void deleteTab (void *voidToDelete);
int mouseInWindow(HWND);