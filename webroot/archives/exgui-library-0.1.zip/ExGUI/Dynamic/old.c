LRESULT CALLBACK tabWindowProcedure (HWND windowHandle, UINT theMessage, WPARAM wParam, LPARAM lParam)
{

    switch (theMessage)
    {
        case LB_GETSELCOUNT:
        /*---------------------------------------------------------------------*/
        /* A message asking for the number of tabs selected.                   */
        /*---------------------------------------------------------------------*/
        /* Message parameters:                                                 */
        /*---------------------------------------------------------------------*/
        /* Not used.                                                           */
        /*---------------------------------------------------------------------*/
        {
            tabList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);
            tempList = tabList;

            count = 0;

            while (tempList)
            {
                if (tempList->data)
                {
                    theTab = (struct tab *)tempList->data;
                    if (theTab->isPressed)
                    {
                        count++;
                    }
                }
                tempList = tempList->next;
            }

            return count;
        }

        case LB_GETSELITEMS:
        /*---------------------------------------------------------------------*/
        /* A message asking for the list indexes to be put into an array.      */
        /*---------------------------------------------------------------------*/
        /* Message parameters:                                                 */
        /*---------------------------------------------------------------------*/
        /* lParam - Integer array.                                             */
        /*---------------------------------------------------------------------*/
        {
            tabList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);
            tempList = tabList;

            tabIndex = 0;
            arrIndex = 0;
            selectedItems = (int *)lParam;

            while (tempList)
            {
                if (tempList->data)
                {
                    theTab = (struct tab *)tempList->data;
                    if (theTab->isPressed)
                    {
                        selectedItems[arrIndex] = tabIndex;
                        arrIndex ++;
                    }
                    tabIndex ++;
                }
                tempList = tempList->next;
            }

            break;
        }

        case LB_ADDSTRING:
        /*---------------------------------------------------------------------*/
        /* A message to add a new tab to the tab menu.                         */
        /*---------------------------------------------------------------------*/
        /* Message parameters:                                                 */
        /*---------------------------------------------------------------------*/
        /* lParam - New string to add.                                         */
        /*---------------------------------------------------------------------*/
        {
            addString = (char *)lParam;

            tabList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            tabToAdd = newTab (addString, TAB_NORMAL);

            addTabToList (tabList, tabToAdd);

            RedrawWindow(windowHandle, NULL, NULL, RDW_INVALIDATE);

            break;
        }

        /*---------------------------------------------------------------------*/
        /* A message to delete a tab item from the menu                        */
        /*---------------------------------------------------------------------*/
        /* Message parameters:                                                 */
        /*---------------------------------------------------------------------*/
        /* wParam - Tab index.                                                 */
        /*---------------------------------------------------------------------*/
        case LB_DELETESTRING:
        {
            deleteString = (int)wParam;

            tabList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            newItem = removeFromList (tabList, deleteString, deleteTab);
            tabList = newItem;

            SetWindowLongPtr (windowHandle, GWLP_USERDATA, (LONG_PTR)tabList);

            RedrawWindow(windowHandle, NULL, NULL, RDW_INVALIDATE);

            break;
        }
        case WM_MOUSEMOVE:
        /*---------------------------------------------------------------------*/
        /* The user has moved the mouse.                                       */
        /*---------------------------------------------------------------------*/
        /* Message parameters:                                                 */
        /*---------------------------------------------------------------------*/
        /* lParam - Mouse position.                                            */
        /*---------------------------------------------------------------------*/
        {
            if (!fInWindow)
            {
               fInWindow = TRUE;
               tme.cbSize = sizeof(TRACKMOUSEEVENT);
               tme.dwFlags = TME_LEAVE;
               tme.hwndTrack =windowHandle;
               TrackMouseEvent(&tme);
            }

            tabList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            tempList = tabList;
            position = 10;
            int redraw = 0;

            int tabFound = 0;
            struct tab *f = NULL;

            while (tempList)
            {
                if (tempList->data)
                {
                    if ((LOWORD(lParam) >= position) && (LOWORD(lParam) <= (position + 70)))
                    {
                        theTab = tempList->data;
                        if (theTab->isPressed == 0)
                        {
                            /* If no previous tabs are highlighted: */
                            if (!tabFound)
                            {
                                if (cursorSet == 0 || cursorSet == 1)
                                {
                                    /* The mouse is over the button, change the mouse: */
                                    newCursor = LoadCursor(0, IDC_HAND);
                                    cursorSet = 2;
                                }
                                 tabFound = 1;
                                theTab->isHighlighted = 1;
                                f = theTab;
                            }
                            else
                            /* This means two tabs are set as highlighted: */
                            {
                                /* We must go through and set them as not highlighted: */
                                tempList = tabList;
                                while (tempList)
                                {
                                    if (tempList->data)
                                    {
                                        theTab = (struct tab *)tempList->data;

                                            theTab->isHighlighted = 0;
                                    }
                                    tempList = tempList->next;
                                }
                            }

                            redraw=1;
                        }
                    }
                    else
                    {
                        theTab = tempList->data;
                        if (theTab->isHighlighted == 1)
                        {
                            theTab->isHighlighted = 0;
                            RedrawWindow(windowHandle, NULL, NULL, RDW_INVALIDATE);
                        }
                    }
                    position += 80;
                }
                tempList = tempList->next;
            }
            if (redraw)
            {
                RedrawWindow(windowHandle, NULL, NULL, RDW_INVALIDATE);
                return 0;
            }
            if (cursorSet == 0 || cursorSet == 2)
            {
                newCursor = LoadCursor(0, IDC_ARROW);
                cursorSet = 1;
            }

            break;
        }
        case WM_LBUTTONDOWN:
        /*---------------------------------------------------------------------*/
        /* The left mouse button has been pressed.                             */
        /*---------------------------------------------------------------------*/
        /* Message parameters:                                                 */
        /*---------------------------------------------------------------------*/
        /* lParam - Mouse position.                                            */
        /*---------------------------------------------------------------------*/
        {
            tabList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            tempList = tabList;
            position = 10;

            while (tempList)
            {
                if (tempList->data)
                {
                    if ((LOWORD(lParam) >= position) && (LOWORD(lParam) <= (position + 70)))
                    {
                        theTab = (struct tab *)tempList->data;
                        if (!theTab->isPressed)
                        {
                            /* This will paint the tab in a 'pressed' state:   */
                            theTab->isPressed = 1;
                            theTab->isHighlighted = 0;
                            newCursor = LoadCursor(0, IDC_ARROW);
                            cursorSet = 1;
                        }
                        RedrawWindow(windowHandle, NULL, NULL, RDW_INVALIDATE);
                        return 0;
                    }
                    position += 80;
                }
                tempList = tempList->next;
            }

            break;
        }


        case WM_LBUTTONUP:
        /*---------------------------------------------------------------------*/
        /* The mouse button has been released.                                 */
        /*---------------------------------------------------------------------*/
        /* Message parameters:                                                 */
        /*---------------------------------------------------------------------*/
        /* lParam - Mouse position.                                            */
        /*---------------------------------------------------------------------*/
        {
            tabList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            tempList = tabList;
            position = 10;

            while (tempList)
            {
                if (tempList->data)
                {
                    if ((LOWORD(lParam) >= position) && (LOWORD(lParam) <= (position + 70)))
                    {
                        /* The user clicked a tab, send the message:           */
                        SendMessage (GetParent(windowHandle), WM_COMMAND, MAKEWPARAM(GetWindowLong(windowHandle, GWL_ID), LBN_SELCHANGE), 0);
                        return 0;
                    }
                    position += 80;
                }
                tempList = tempList->next;
            }
            break;
        }
        case WM_PAINT:
        /*---------------------------------------------------------------------*/
        /* The window needs to be painted.                                     */
        /*---------------------------------------------------------------------*/
        /* Message parameters:                                                 */
        /*---------------------------------------------------------------------*/
        /* Not used.                                                           */
        /*---------------------------------------------------------------------*/
        {

            /* Get the tab list from our window:                               */
            tabList = (struct list *)GetWindowLongPtr (windowHandle, GWLP_USERDATA);

            GetWindowRect (windowHandle, &windowRect);

            /* Begin paint:                                                    */
            hdc = BeginPaint (windowHandle, &ps);
            hdcMem = CreateCompatibleDC (hdc);

            int i;
            int x = 12;
            for (i = 1; i < ((windowRect.right - windowRect.left) / 12); i++)
            {
                if (i == ((windowRect.right - windowRect.left) / 12) - 1)
                x-=5;
                (void) drawTransparentBitmap( hdc, tabMiddle,
                x,  0,

                (COLORREF) 0xFF00FF);
                x += 12;
            }

            (void) drawTransparentBitmap( hdc, tabLeft,
            0, 0,

            (COLORREF) 0xFF00FF);

            (void) drawTransparentBitmap( hdc, tabRight,
            (windowRect.right - windowRect.left) - 11, 0,

            (COLORREF) 0xFF00FF);

            /* Apply our new font settings:                                    */
            HFONT oldFont = (HFONT)SelectObject (hdc, getMainFont ());
            SetBkMode (hdc, TRANSPARENT);
			SetTextColor (hdc, RGB (255,255,255));

            /* Create some coordinates for the text.                           */
            LPRECT prc = malloc (sizeof *prc);
            prc->left = 10;
            prc->top = 5;
            prc->right = prc->left + 70;
            prc->bottom = TABMENU_HEIGHT - 4;

            /* Print out each tab:                                             */
            tempList = tabList;
            while (tempList)
            {
                if (tempList->data)
                /* If there is a string to print:                              */
                {
                    /* Convert from void * to struct tab * (implicit)          */
                    theTab = tempList->data;

                    if (theTab->isPressed)
                    {
                        hbmOld = SelectObject(hdcMem, tabPressedMiddle);
                        GetObject(tabPressedMiddle, sizeof(bm), &bm);
                        StretchBlt (hdc, prc->left, 0, 70, TABMENU_HEIGHT,
                        hdcMem, 0, 0, 10, TABMENU_HEIGHT, SRCCOPY);

                        hbmOld = SelectObject(hdcMem, tabPressedLeft);
                        GetObject(tabPressedLeft, sizeof(bm), &bm);
                        StretchBlt (hdc, prc->left, 0, bm.bmWidth, TABMENU_HEIGHT,
                        hdcMem, 0, 0, 10, TABMENU_HEIGHT, SRCCOPY);

                        hbmOld = SelectObject(hdcMem, tabPressedRight);
                        GetObject(tabPressedRight, sizeof(bm), &bm);
                        StretchBlt (hdc, prc->left + (70 - bm.bmWidth), 0, bm.bmWidth, TABMENU_HEIGHT,
                        hdcMem, 0, 0, 10, TABMENU_HEIGHT, SRCCOPY);
                    }

                    if (theTab->isHighlighted)
                    {
                        hbmOld = SelectObject(hdcMem, tabHoverMiddle);
                        GetObject(tabHoverMiddle, sizeof(bm), &bm);
                        StretchBlt (hdc, prc->left, 0, 70, TABMENU_HEIGHT,
                        hdcMem, 0, 0, 10, TABMENU_HEIGHT, SRCCOPY);

                        hbmOld = SelectObject(hdcMem, tabHoverLeft);
                        GetObject(tabHoverLeft, sizeof(bm), &bm);
                        StretchBlt (hdc, prc->left, 0, bm.bmWidth, TABMENU_HEIGHT,
                        hdcMem, 0, 0, 10, TABMENU_HEIGHT, SRCCOPY);

                        hbmOld = SelectObject(hdcMem, tabHoverRight);
                        GetObject(tabHoverRight, sizeof(bm), &bm);
                        StretchBlt (hdc, prc->left + (70 - bm.bmWidth), 0, bm.bmWidth, TABMENU_HEIGHT,
                        hdcMem, 0, 0, 10, TABMENU_HEIGHT, SRCCOPY);
                    }

                    /* Draw the text, centered:                                */
                    DrawText(hdc, theTab->caption, -1, prc, DT_SINGLELINE | DT_CENTER | DT_VCENTER);

                    /* Change the position:                                    */
                    prc->left += 80;
                    prc->right = prc->left + 70;
                }
                /* Go the next list item:                                      */
                tempList = tempList->next;
            }

            /* Put the old object back:                                        */
            SelectObject(hdc, oldFont);

            /* Finish painting:                                                */
            DeleteDC (hdcMem);
            EndPaint (windowHandle, &ps);
            free (prc);
            break;
        }

        default: return DefWindowProc (windowHandle, theMessage, wParam, lParam);
    }

    return 0;
}

/*------------------------------ addTabToList () ------------------------------*/
/*                                                                             */
/*  The add a new tab to a tab list.                                           */
/*                                                                             */
/*-------------------------------- Parameters ---------------------------------*/
/*                                                                             */
/*  theList    - List to add to.                                               */
/*  theTab     - New tab object.                                               */
/*------------------------------- Return value --------------------------------*/
/*                                                                             */
/*  None.                                                                      */
/*                                                                             */
/*-----------------------------------------------------------------------------*/
void addTabToList (struct list *theList, struct tab *theTab)
{
    struct list *newListItem;

    newListItem = addToList (theList, theTab);
}


/*--------------------------------- newTab () ---------------------------------*/
/*                                                                             */
/*  Create a new tab object.                                                   */
/*                                                                             */
/*-------------------------------- Parameters ---------------------------------*/
/*                                                                             */
/*  caption    - Caption of the tab.                                           */
/*  isPressed  - State of the tab.                                             */
/*------------------------------- Return value --------------------------------*/
/*                                                                             */
/*  struct tab *                                                               */
/*                                                                             */
/*-----------------------------------------------------------------------------*/
struct tab *newTab (const char *caption, int isPressed)
{
    struct tab *toCreate;

    toCreate = malloc (sizeof *toCreate);
    if (caption != NULL)
    {
        toCreate->caption = malloc (strlen(caption) + 1);
        strcpy(toCreate->caption, caption);
    }
    else
    {
        toCreate->caption = NULL;
    }
    toCreate->isPressed = isPressed;
    toCreate->isHighlighted = 0;

    return toCreate;
}


/*-------------------------------- deleteTab () -------------------------------*/
/*                                                                             */
/*  Delete a tab object                                                        */
/*                                                                             */
/*-------------------------------- Parameters ---------------------------------*/
/*                                                                             */
/*  voidToDelete - A void pointer to the tab..                                 */
/*                                                                             */
/*------------------------------- Return value --------------------------------*/
/*                                                                             */
/*  None.                                                                      */
/*                                                                             */
/*-----------------------------------------------------------------------------*/
void deleteTab (void *voidToDelete)
{
    struct tab *toDelete;
    toDelete = voidToDelete;
    if (toDelete->caption) free(toDelete->caption);
    free (toDelete);
}
