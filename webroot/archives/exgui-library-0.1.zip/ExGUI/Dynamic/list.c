#include "list.h"
#include <windows.h>

struct list *newList ()
{
    struct list *theList;

    theList = malloc(sizeof *theList);

    if (!theList) return theList;

    theList->next = NULL;
    theList->data = NULL;

    return theList;
}

void deleteList(struct list *toDelete)
{
    free (toDelete);
}

struct list *addToList (struct list *theList, void *theData)
{
    struct list *newListItem;

    if (theList->data)
    {
        newListItem = newList ();

        while (theList->next)
        {
            theList = theList->next;
        }

        theList->next = newListItem;
        newListItem->data = theData;
    }
    else
    {
        theList->data = theData;
        newListItem = theList;
    }

    return newListItem;
}

struct list *removeFromList (struct list *theList, int listIndex, deleteFunc deleteWith)
{
    struct list *tempList;
    struct list *lastList;
    struct list *newList;
    int tabCount;

    if ((!theList->next) || (listIndex == 0))
    {
        if (theList->data) deleteWith(theList->data);

        if (theList->next)
        {
            newList = theList->next;
            free (theList);
            return newList;
        }
        else
        {
            theList->data = NULL;
            return theList;
        }
    }

    tempList = theList;
    lastList = theList;
    tabCount = 0;

    while ((tempList) && (tabCount <= listIndex))
    {
        if (listIndex == tabCount)
        {
            if (lastList == theList)
            {
                if (lastList->data) deleteWith(lastList->data);
                lastList->data = NULL;
                return tempList;
            }

            if (!tempList->next)
            {
                lastList->next = NULL;
            }
            else
            {
                lastList->next = tempList->next;
            }

            if (tempList->data) deleteWith(tempList->data);
            free(tempList);

            break;
        }

        lastList = tempList;
        tempList = tempList->next;

        tabCount++;
    }

    return theList;
}

void printList (struct list *theList)
{
    struct list *tempList;

    tempList = theList;
    while (tempList)
    {
        if (tempList->data)
        {
            MessageBox(NULL, tempList->data, "List item", 0);
        }
        else
        {
            MessageBox(NULL, "[no data]", "List item", 0);
        }
        tempList = tempList->next;
    }
}
