/*--------------------------------- theme.c -----------------------------------*/
/*                                                                             */
/*  This module handles the bitmaps and fonts for the window controls.         */
/*                                                                             */
/*                                                                             */
/*-----------------------------------------------------------------------------*/


/* Required for the list of bitmaps:                                           */
#include "list.h"

/* Required for the bitmap list structures:                                    */
#include "theme.h"

/* Required for the PathFileExists function.                                   */
#include <shlwapi.h>

/* Globals: */
struct list *controlBitmaps = NULL;
HFONT mainFont = NULL;

void drawText (HDC windowDC, char *text, int left, int top, int width, int height,
    HFONT *font, int align)
{
    /* Select our font into the DC. */
    HFONT oldFont;

    oldFont = SelectObject (windowDC, *font);
    SetBkMode (windowDC, TRANSPARENT);

    LPRECT textRect = malloc (sizeof *textRect);
    textRect->left = left;
    textRect->top = top;
    textRect->right = width;
    textRect->bottom = height;

    if (align)
        DrawText (windowDC, text, -1, textRect, DT_SINGLELINE | DT_VCENTER | align);
    else
        DrawText (windowDC, text, -1, textRect, DT_SINGLELINE | DT_VCENTER);

    SelectObject (windowDC, oldFont);
}

void drawRoundRect (HDC windowDC, int left, int top, int width, int height,
    int swidth, int sheight, HBRUSH newBrush, HPEN newPen)
{
    HPEN oldPen;
    HBRUSH oldBrush;

    /* Create a pen and select it into the DC, storing the old one. */
    oldPen = SelectObject(windowDC, newPen);
    oldBrush = SelectObject(windowDC, newBrush);

    /* Make the background transprent. */
    SetBkMode(windowDC, TRANSPARENT);

    /* Draw the rectangle. */
    RoundRect(windowDC, left, top, width, height, swidth, sheight);

    /* Restore the old pen and delete the new one. */
    SelectObject (windowDC, oldPen);
    SelectObject (windowDC, oldBrush);
}

void drawRect (HDC windowDC, int left, int top, int width, int height,
    HBRUSH newBrush, HPEN newPen)
{
    HPEN oldPen;
    HBRUSH oldBrush;

    /* Create a pen and select it into the DC, storing the old one. */
    oldPen = SelectObject (windowDC, newPen);
    oldBrush = SelectObject (windowDC, newBrush);

    /* Make the background transprent. */
    SetBkMode (windowDC, TRANSPARENT);

    /* Draw the rectangle. */
    Rectangle (windowDC, left, top, width, height);

    /* Restore the old pen and delete the new one. */
    SelectObject (windowDC, oldPen);
    SelectObject (windowDC, oldBrush);
}

void drawNormalBitmap (HDC windowDC, HBITMAP theBitmap, int left, int top)
{
    HDC bitmapDC;
    BITMAP bitmapInfo;
    HBITMAP oldWindowObjects;

    /* Create a DC compatible with our device: */
    bitmapDC = CreateCompatibleDC (windowDC);
    /* Temporarily store the current objects to put back later: */
    oldWindowObjects = SelectObject(bitmapDC, theBitmap); /* Put the bitmap in it. */

    /* Get the backdrop dimensions: */
    GetObject(theBitmap, sizeof (bitmapInfo), &bitmapInfo);

    /* Paint the backdrop to the window: */
    BitBlt (windowDC, left, top, bitmapInfo.bmWidth, bitmapInfo.bmHeight,
        bitmapDC, 0, 0, SRCCOPY);

    /* Put the old objects back, and delete the DC. */
    SelectObject (bitmapDC, oldWindowObjects);
    DeleteDC (bitmapDC);
}

void drawTransparentBitmap(HDC hdc, HBITMAP hBitmap, int xStart,
                           int yStart, COLORREF cTransparentColor)
{
   BITMAP     bm;
   COLORREF   cColor;
   HBITMAP    bmAndBack, bmAndObject, bmAndMem, bmSave;
   HBITMAP    bmBackOld, bmObjectOld, bmMemOld, bmSaveOld;
   HDC        hdcMem, hdcBack, hdcObject, hdcTemp, hdcSave;
   POINT      ptSize;

   hdcTemp = CreateCompatibleDC(hdc);
   SelectObject(hdcTemp, hBitmap);   // Select the bitmap

   GetObject(hBitmap, sizeof(BITMAP), (LPSTR)&bm);
   ptSize.x = bm.bmWidth;            // Get width of bitmap
   ptSize.y = bm.bmHeight;           // Get height of bitmap
   DPtoLP(hdcTemp, &ptSize, 1);      // Convert from device

                                     // to logical points

   // Create some DCs to hold temporary data.
   hdcBack   = CreateCompatibleDC(hdc);
   hdcObject = CreateCompatibleDC(hdc);
   hdcMem    = CreateCompatibleDC(hdc);
   hdcSave   = CreateCompatibleDC(hdc);

   // Create a bitmap for each DC. DCs are required for a number of
   // GDI functions.

   // Monochrome DC
   bmAndBack   = CreateBitmap(ptSize.x, ptSize.y, 1, 1, NULL);

   // Monochrome DC
   bmAndObject = CreateBitmap(ptSize.x, ptSize.y, 1, 1, NULL);

   bmAndMem    = CreateCompatibleBitmap(hdc, ptSize.x, ptSize.y);
   bmSave      = CreateCompatibleBitmap(hdc, ptSize.x, ptSize.y);

   // Each DC must select a bitmap object to store pixel data.
   bmBackOld   = SelectObject(hdcBack, bmAndBack);
   bmObjectOld = SelectObject(hdcObject, bmAndObject);
   bmMemOld    = SelectObject(hdcMem, bmAndMem);
   bmSaveOld   = SelectObject(hdcSave, bmSave);

   // Set proper mapping mode.
   SetMapMode(hdcTemp, GetMapMode(hdc));

   // Save the bitmap sent here, because it will be overwritten.
   BitBlt(hdcSave, 0, 0, ptSize.x, ptSize.y, hdcTemp, 0, 0, SRCCOPY);

   // Set the background color of the source DC to the color.
   // contained in the parts of the bitmap that should be transparent
   cColor = SetBkColor(hdcTemp, cTransparentColor);

   // Create the object mask for the bitmap by performing a BitBlt
   // from the source bitmap to a monochrome bitmap.
   BitBlt(hdcObject, 0, 0, ptSize.x, ptSize.y, hdcTemp, 0, 0,
          SRCCOPY);

   // Set the background color of the source DC back to the original
   // color.
   SetBkColor(hdcTemp, cColor);

   // Create the inverse of the object mask.
   BitBlt(hdcBack, 0, 0, ptSize.x, ptSize.y, hdcObject, 0, 0,
          NOTSRCCOPY);

   // Copy the background of the main DC to the destination.
   BitBlt(hdcMem, 0, 0, ptSize.x, ptSize.y, hdc, xStart, yStart,
          SRCCOPY);

   // Mask out the places where the bitmap will be placed.
   BitBlt(hdcMem, 0, 0, ptSize.x, ptSize.y, hdcObject, 0, 0, SRCAND);

   // Mask out the transparent colored pixels on the bitmap.
   BitBlt(hdcTemp, 0, 0, ptSize.x, ptSize.y, hdcBack, 0, 0, SRCAND);

   // XOR the bitmap with the background on the destination DC.
   BitBlt(hdcMem, 0, 0, ptSize.x, ptSize.y, hdcTemp, 0, 0, SRCPAINT);

   // Copy the destination to the screen.
   BitBlt(hdc, xStart, yStart, ptSize.x, ptSize.y, hdcMem, 0, 0,
          SRCCOPY);

   // Place the original bitmap back into the bitmap sent here.
   BitBlt(hdcTemp, 0, 0, ptSize.x, ptSize.y, hdcSave, 0, 0, SRCCOPY);

   // Delete the memory bitmaps.
   DeleteObject(SelectObject(hdcBack, bmBackOld));
   DeleteObject(SelectObject(hdcObject, bmObjectOld));
   DeleteObject(SelectObject(hdcMem, bmMemOld));
   DeleteObject(SelectObject(hdcSave, bmSaveOld));

   // Delete the memory DCs.
   DeleteDC(hdcMem);
   DeleteDC(hdcBack);
   DeleteDC(hdcObject);
   DeleteDC(hdcSave);
   DeleteDC(hdcTemp);
}

/* --------------------------------------------------------------------- */
/* Used to get the main HFONT object.   */
/* --------------------------------------------------------------------- */
HFONT *getMainFont (void)
{

    if (mainFont == NULL) mainFont = CreateFont
    (13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "Verdana");
    return &mainFont;
}

void deleteMainFont (void)
{
    DeleteObject (mainFont);
}

/* --------------------------------------------------------------------- */
/* Create a list of bitmaps for the controls and load the bitmap files.  */
/* --------------------------------------------------------------------- */
void getBitmaps (void)
{
    struct bitmaplist *bitmapListHolder = NULL;
    struct list *bitmapList = NULL;
    struct bitmap *controlBitmap = NULL;

    /* Create a list of bitmaps: */
    controlBitmaps = newList ();

    /* Add our control names to the list:  */
    addToList (controlBitmaps, newBitmapList("button"));
    addToList (controlBitmaps, newBitmapList("tab"));
    addToList (controlBitmaps, newBitmapList("link"));
    addToList (controlBitmaps, newBitmapList("frame"));
    addToList (controlBitmaps, newBitmapList("list"));
    addToList (controlBitmaps, newBitmapList("windowbuttons"));
    addToList (controlBitmaps, newBitmapList("backdrop"));

    /* Get pointer to the bitmap list: */
    bitmapListHolder = findBitmapList (controlBitmaps, "button");
    /* Point to control's list of bitmaps: */
    bitmapList = bitmapListHolder->bitmapList;
    /* Load bitmap from file: */
    controlBitmap = newControlBitmap ("buttonLeft", "bitmap/buttonleft.bmp");
    /* Add new bitmap to the list: */
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("buttonMiddle", "bitmap/buttonmiddle.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("buttonRight", "bitmap/buttonright.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("buttonLeftPressed", "bitmap/buttonleftpressed.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("buttonMiddlePressed", "bitmap/buttonmiddlepressed.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("buttonRightPressed", "bitmap/buttonrightpressed.bmp");
    addToList (bitmapList, controlBitmap);

    bitmapListHolder = findBitmapList (controlBitmaps, "tab");
    bitmapList = bitmapListHolder->bitmapList;
    controlBitmap = newControlBitmap ("tabLeft", "bitmap/tableft.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("tabMiddle", "bitmap/tabmiddle.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("tabRight", "bitmap/tabright.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("tabPressedLeft", "bitmap/tabpressedleft.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("tabPressedMiddle", "bitmap/tabpressedmiddle.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("tabPressedRight", "bitmap/tabpressedright.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("tabHoverLeft", "bitmap/tabhoverleft.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("tabHoverMiddle", "bitmap/tabhovermiddle.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("tabHoverRight", "bitmap/tabhoverright.bmp");
    addToList (bitmapList, controlBitmap);

    bitmapListHolder = findBitmapList (controlBitmaps, "link");
    bitmapList = bitmapListHolder->bitmapList;
    controlBitmap = newControlBitmap ("link", "bitmap/link.bmp");
    addToList (bitmapList, controlBitmap);

    bitmapListHolder = findBitmapList (controlBitmaps, "frame");
    bitmapList = bitmapListHolder->bitmapList;
    controlBitmap = newControlBitmap ("frameLeft", "bitmap/frameleft.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("frameMiddle", "bitmap/framemiddle.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("frameRight", "bitmap/frameright.bmp");
    addToList (bitmapList, controlBitmap);

    bitmapListHolder = findBitmapList (controlBitmaps, "list");
    bitmapList = bitmapListHolder->bitmapList;
    controlBitmap = newControlBitmap ("list", "bitmap/list.bmp");
    addToList (bitmapList, controlBitmap);

    bitmapListHolder = findBitmapList (controlBitmaps, "backdrop");
    bitmapList = bitmapListHolder->bitmapList;
    controlBitmap = newControlBitmap ("backdrop", "bitmap/backdrop.bmp");
    addToList (bitmapList, controlBitmap);

    bitmapListHolder = findBitmapList (controlBitmaps, "windowbuttons");
    bitmapList = bitmapListHolder->bitmapList;
    controlBitmap = newControlBitmap ("windowbuttonsMinimize", "bitmap/windowbuttonminimize.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("windowbuttonsMaximize", "bitmap/windowbuttonmaximize.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("windowbuttonsClose", "bitmap/windowbuttonclose.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("windowbuttonsMinimizeHover", "bitmap/windowbuttonminimizehover.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("windowbuttonsMaximizeHover", "bitmap/windowbuttonmaximizehover.bmp");
    addToList (bitmapList, controlBitmap);
    controlBitmap = newControlBitmap ("windowbuttonsCloseHover", "bitmap/windowbuttonclosehover.bmp");
    addToList (bitmapList, controlBitmap);
}

void deleteBitmaps (void)
{
}

/* ----------------------------------------------------------------------- */
/* Used to get the HBITMAP object of a certain control.                    */
/* ----------------------------------------------------------------------- */
HBITMAP getControlBitmap (char *controlName, char *bitmapName)
{
    struct bitmaplist *bitmapList;
    struct bitmap *controlBitmap;

    /* First find the bitmaplist for the respective control: */
    bitmapList = findBitmapList (controlBitmaps, controlName);
    if (!bitmapList) return (HBITMAP)NULL;

    /* Second find the bitmap that corresponds to bitmapName from that list: */
    controlBitmap = findBitmap (bitmapList->bitmapList, bitmapName);
    if (!controlBitmap) return (HBITMAP)NULL;

    return controlBitmap->theBitmap;
}

/* ----------------------------------------------------------------------- */
/* Create a new bitmaplist object and copy the control name to the object. */
/* ----------------------------------------------------------------------- */
struct bitmaplist *newBitmapList (char *controlName)
{
    struct bitmaplist *newBitmapList;

    newBitmapList = malloc(sizeof *newBitmapList);

    newBitmapList->controlName = malloc(strlen(controlName) + 1);
    strcpy(newBitmapList->controlName, controlName);

    newBitmapList->bitmapList = newList ();

    return newBitmapList;
}

/* --------------------------------------------------------------------- */
/* Creates a new bitmap object for use with bitmaplist.                  */
/* --------------------------------------------------------------------- */
struct bitmap *newControlBitmap (char *bitmapName, char *fileName)
{
    struct bitmap *newBitmap;

    newBitmap = malloc(sizeof *newBitmap);
    /* Copy bitmap name: */
    newBitmap->bitmapName = malloc(strlen(bitmapName) + 1);
    strcpy(newBitmap->bitmapName, bitmapName);

    if (PathFileExists(fileName))
    /* Load the bitmap: */
        newBitmap->theBitmap = (HBITMAP)LoadImage
        (0, fileName, IMAGE_BITMAP,0, 0, LR_LOADFROMFILE);
    else
    /* Set the bitmap as empty: */
        newBitmap->theBitmap = NULL;

    return newBitmap;
}

/* --------------------------------------------------------------------- */
/* Deconstructor for our bitmap structure.                               */
/* --------------------------------------------------------------------- */
void deleteControlBitmap (struct bitmap *toDelete)
{
    if (toDelete->theBitmap != NULL)
        DeleteObject (toDelete->theBitmap);
    free (toDelete);
}

/* --------------------------------------------------------------------- */
/* Finds a bitmap list from a bitmaplist object.                         */
/* --------------------------------------------------------------------- */
struct bitmaplist *findBitmapList (struct list *toSearch, char *controlName)
{
    struct bitmaplist *thisList;

    while (toSearch)
    {
        thisList = toSearch->data;
        if (!strcmp(thisList->controlName, controlName)) return thisList;
        toSearch = toSearch->next;
    }

    return NULL;
}


/* --------------------------------------------------------------------- */
/* Creates a new bitmap object for use with bitmaplist.                  */
/* --------------------------------------------------------------------- */
struct bitmap *findBitmap (struct list *toSearch, char *bitmapName)
{
    struct bitmap *thisBitmap;

    while (toSearch)
    {
        thisBitmap = toSearch->data;
        if (!strcmp(thisBitmap->bitmapName, bitmapName)) return thisBitmap;
        toSearch = toSearch->next;
    }

    return NULL;
}
