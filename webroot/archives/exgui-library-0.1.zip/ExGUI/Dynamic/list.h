/*---------------------------------- list.h -----------------------------------*/
/*                                                                             */
/*  This module handles all the operations for the tab menu control.           */
/*                                                                             */
/*-----------------------------------------------------------------------------*/

#ifndef _LIST_H_
#define _LIST_H_ 1

#include <stdlib.h>

struct list
{
    struct list *next;
    void *data;
};

typedef void (*deleteFunc)(void *);
struct list *newList ();
struct list *addToList (struct list *, void *);
struct list *removeFromList (struct list *, int, deleteFunc);
void printList (struct list *);
void deleteList(struct list *);

#endif
