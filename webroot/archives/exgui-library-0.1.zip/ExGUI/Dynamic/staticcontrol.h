#include <windows.h>

LRESULT CALLBACK staticWindowProcedure (HWND, UINT, WPARAM, LPARAM);
