#include "list.h"
#include <windows.h>

struct bitmaplist
{
    char *controlName;
    struct list *bitmapList;
};

struct bitmap
{
    char *bitmapName;
    HBITMAP theBitmap;
};

HFONT *getMainFont (void);
void deleteMainFont (void);
void getBitmaps (void);
void deleteBitmaps (void);
HBITMAP getControlBitmap (char *, char *);
struct bitmaplist *findBitmapList (struct list *, char *);
struct bitmaplist *newBitmapList (char *);
struct bitmap *findBitmap (struct list *, char *);
struct bitmap *newControlBitmap (char *, char *);
void deleteControlBitmap (struct bitmap *);
HRGN makeTransparentRegion (HWND windowHandle);
void drawNormalBitmap (HDC, HBITMAP, int, int);
void drawTransparentBitmap (HDC, HBITMAP, int, int, COLORREF);
void drawRoundRect (HDC, int, int, int, int, int, int, HBRUSH, HPEN);
void drawRect (HDC, int, int, int, int, HBRUSH, HPEN);
void drawText (HDC, char *, int, int, int, int, HFONT *, int);
