/* ------------------------------------------------------------------- */
/* This code has been commented and recoded so that it is correct.     */
/* ------------------------------------------------------------------- */

#define WINVER 0x500 /* This is required for the AlphaBlend function. */

#include "framecontrol.h"
#include "theme.h" /* This header has functions for getting/drawing bitmaps. */

#include <windows.h>
#include <wingdi.h> /* Needed for AlphaBlend. */

/* ------------------------------------------------------------------- */
/* All the events for our frame window occur here.                     */
/* ------------------------------------------------------------------- */
LRESULT CALLBACK frameWindowProcedure (HWND windowHandle, UINT theMessage, WPARAM wParam, LPARAM lParam)
{
    /* Use for drawing the top part of the frame */
    /* (Assigned in WM_CREATE, used in WM_PAINT) */
    static HBITMAP frameLeft = NULL;
    static HBITMAP frameRight = NULL;
    static HBITMAP frameMiddle = NULL;

    /* (Used for various drawing in WM_PAINT) */
    HDC windowDC;
    PAINTSTRUCT paintStruct;
    BITMAP bitmapInfo;
    HPEN newPen;
    HBRUSH newBrush;

    RECT windowRect; /* Used for dimensions, etc. */
    int windowWidth;
    int windowHeight;
    int drawPosition;
    int maxDraw;

    char frameCaption [513];

    /* ----------------------------------------------- */
    /* No more objects are declared beyond this point. */
    /* ----------------------------------------------- */

    switch (theMessage)
    {
        case WM_COMMAND:
        /* User controls send this message. */
        {
            /* We need to forward these messages to the main window and ignore them. */
            SendMessage (GetParent(windowHandle), theMessage, wParam, lParam);

            return 0; /* Finish up here. */
        }
        case WM_CREATE:
        /* Some window creation procedures. */
        {
            /* Make sure that our frame is transparent. */
            SetWindowLong (windowHandle, GWL_EXSTYLE,
            GetWindowLong (windowHandle, GWL_EXSTYLE) + WS_EX_TRANSPARENT);

            /* Get our bitmaps: */
            frameLeft   = getControlBitmap ("frame", "frameLeft");
            frameMiddle = getControlBitmap ("frame", "frameMiddle");
            frameRight  = getControlBitmap ("frame", "frameRight");

            break;
        }
        case WM_LBUTTONDOWN:
        /* The user is moving the window. */
        {
            /* We simulating a press of the window caption for dragging. */
            /* Note: If the frame's parent is not the main window it is not our problem. */
            SendMessage (GetParent(windowHandle), WM_NCLBUTTONDOWN, HTCAPTION, 0);

            break;
        }
        case WM_SIZE:
        {
            RedrawWindow (windowHandle, NULL, NULL, RDW_INVALIDATE);
            break;
        }
        case WM_PAINT:
        /* Paint our caption and borders. */
        {
            /* Get the window size: */
            GetWindowRect(windowHandle, &windowRect);
            windowWidth = windowRect.right - windowRect.left; /* Save us taking up space. */
            windowHeight = windowRect.bottom - windowRect.top; /* Again, this is about code space. */

            /* Create a DC object of our window: */
            windowDC = BeginPaint (windowHandle, &paintStruct);

            /* Draw the borders, making the purple bits transparent. */
            drawTransparentBitmap (windowDC, frameLeft, 0, 0, 0xFF00FF);
            drawTransparentBitmap (windowDC, frameRight, windowWidth - 12, 0, 0xFF00FF);

            /* Draw the middle part of the border. */
            GetObject (frameMiddle, sizeof bitmapInfo, &bitmapInfo);
            maxDraw = windowWidth - (bitmapInfo.bmWidth * 2);
            for (drawPosition = bitmapInfo.bmWidth; ; drawPosition += bitmapInfo.bmWidth)
            {
                /* Make sure we don't draw over the right border. */
                if (drawPosition > maxDraw) drawPosition = maxDraw;
                drawTransparentBitmap (windowDC, frameMiddle, drawPosition, 0, 0xFF00FF);
                if (drawPosition == maxDraw) break;
            }

            /* Now we need to draw our lines... */
            newPen = CreatePen (PS_SOLID, 1, RGB (210, 210, 210)); /* Border colour. */
            newBrush = GetStockObject(NULL_BRUSH); /* Transparent rectangle. */
            drawRect (windowDC, 0, bitmapInfo.bmHeight - 1, windowWidth - 1, windowHeight, newBrush, newPen);
            /* Finish up with our two objects. */
            DeleteObject (newPen);
            DeleteObject (newBrush);

            GetWindowText (windowHandle, frameCaption, 512);
            SetTextColor (windowDC, RGB (0, 0, 0));
            drawText (windowDC, frameCaption, 15, 0, windowWidth, bitmapInfo.bmHeight, getMainFont (), 0);

            /* Delete the DC. */
            EndPaint (windowHandle, &paintStruct);

            break;
        }
        default: return DefWindowProc (windowHandle, theMessage, wParam, lParam);
    }

    /* We don't have to forward messages to anyone. */
    return 0;
}