/* TODO: Free the bitmap list when the DLL is unloaded. */

/* --------------------------------------------------------------------------- */
/*  This is the main entry point of the library. You must use the Windows API  */
/*  to interface with this library.                                            */
/* --------------------------------------------------------------------------- */

/* For registerClasses function: */
#include "exgui.h"

/* These provide the window procedures for the registerClasses function: */
#include "tabcontrol.h"
#include "framecontrol.h"
#include "listcontrol.h"
#include "linkcontrol.h"
#include "staticcontrol.h"
#include "editcontrol.h"
#include "buttoncontrol.h"
#include "windowcontrol.h"
#include "infocontrol.h"
#include "layoutframecontrol.h"

/* Required for getBitmaps: */
#include "theme.h"

/* System libraries: */
#include <windows.h>

/* ------------------------------------------------------------------- */
/* This is the first function called which loads our theme bitmaps and */
/*  registers our window classes.                                      */
/* ------------------------------------------------------------------- */
BOOL WINAPI DllMain (HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch (fdwReason)
    {
        case DLL_PROCESS_ATTACH:
        {
            getBitmaps ();
            registerClasses ();
            if (!LoadLibrary ("Riched20.dll"))
            {
                MessageBox (NULL, "Unable to load rich edit library!", "", 0);
                return FALSE;
            }
            break;
        }
        case DLL_PROCESS_DETACH:
        {
            deleteMainFont ();
            deleteBitmaps ();
        }
    }

    return TRUE;
}

/* ------------------------------------------------------------------- */
/* This function is used to register all of the window classes.        */
/* ------------------------------------------------------------------- */
int registerClasses (void)
{
    WNDCLASSEX wincl;

    /* ---------------------------------------------------------------------- */
    /* Window control                                                         */
    /* ---------------------------------------------------------------------- */
    /* The main window type with no menu or extra window data: */
    wincl.hInstance = GetModuleHandle (0);
    wincl.lpszClassName = "ExGUIWindow";
    wincl.lpfnWndProc = dialogWindowProcedure;
    wincl.style = 0;
    wincl.cbSize = sizeof (WNDCLASSEX);
    wincl.hIcon  = NULL;
    wincl.hIconSm  = NULL;
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName  = NULL;
    wincl.cbClsExtra = 0;
    wincl.cbWndExtra = 0;
    wincl.hbrBackground = (HBRUSH) CreateSolidBrush(RGB(255, 255, 255));
    if (!RegisterClassEx (&wincl)) return FALSE;


    /* ---------------------------------------------------------------------- */
    /* Button control                                                         */
    /* ---------------------------------------------------------------------- */
    wincl.lpszClassName = "ExGUIButton";
    wincl.lpfnWndProc = buttonWindowProcedure;
    /* The cbWndExtra allocates enough space for us to store an int value  */
    /* of 0 or 1, for distinquishing between button states:                */
    wincl.cbWndExtra = sizeof (int);
    wincl.hbrBackground = NULL;
    if (!RegisterClassEx (&wincl)) return FALSE;


    /* ---------------------------------------------------------------------- */
    /* Tab menu control                                                       */
    /* ---------------------------------------------------------------------- */
    wincl.lpszClassName = "ExGUITabMenu";
    wincl.lpfnWndProc = tabWindowProcedure;
    /* The cbWndExtra allocates enough space for us to store a pointer value  */
    /* for storing a list of tab items:                                       */
    wincl.cbWndExtra = sizeof (void *);
    wincl.hbrBackground = (HBRUSH) CreateSolidBrush(RGB(255, 255, 255));
    if (!RegisterClassEx (&wincl)) return FALSE;


    /* ---------------------------------------------------------------------- */
    /* Link control                                                           */
    /* ---------------------------------------------------------------------- */
    wincl.lpszClassName = "ExGUILink";
    wincl.lpfnWndProc = linkWindowProcedure;
    wincl.cbWndExtra = 0;
    wincl.hbrBackground = NULL;
    if (!RegisterClassEx (&wincl)) return FALSE;


    /* ---------------------------------------------------------------------- */
    /* Frame control                                                          */
    /* ---------------------------------------------------------------------- */
    wincl.lpszClassName = "ExGUIFrame";
    wincl.lpfnWndProc = frameWindowProcedure;
    wincl.cbWndExtra = 0;
    if (!RegisterClassEx (&wincl)) return FALSE;


    /* ---------------------------------------------------------------------- */
    /* List  control                                                          */
    /* ---------------------------------------------------------------------- */
    wincl.lpszClassName = "ExGUIList";
    wincl.lpfnWndProc = listWindowProcedure;
    /* The cbWndExtra allocates enough space for us to store a pointer value  */
    /* for storing a list of items:                                           */
    wincl.cbWndExtra = sizeof (void *);
    if (!RegisterClassEx (&wincl)) return FALSE;


    /* ---------------------------------------------------------------------- */
    /* Table  control (Incompleted)                                           */
    /* ---------------------------------------------------------------------- */
    wincl.lpszClassName = "ExGUITable";
    wincl.lpfnWndProc = frameWindowProcedure;
    wincl.cbWndExtra = 0;
    if (!RegisterClassEx (&wincl)) return FALSE;


    /* ---------------------------------------------------------------------- */
    /* Static  control                                                        */
    /* ---------------------------------------------------------------------- */
    wincl.lpszClassName = "ExGUIStatic";
    wincl.lpfnWndProc = staticWindowProcedure;
    wincl.cbWndExtra = 0;
    if (!RegisterClassEx (&wincl)) return FALSE;


    /* ---------------------------------------------------------------------- */
    /* Edit control                                                           */
    /* ---------------------------------------------------------------------- */
    wincl.lpszClassName = "ExGUIEdit";
    wincl.lpfnWndProc = editWindowProcedure;
    wincl.cbWndExtra = sizeof (HWND);
    wincl.hbrBackground = (HBRUSH) CreateSolidBrush(RGB(100, 100, 100));
    if (!RegisterClassEx (&wincl)) return FALSE;

    wincl.lpszClassName = "ExGUILayoutFrame";
    wincl.lpfnWndProc = layoutFrameWindowProcedure;
    wincl.cbWndExtra = 0;
    wincl.hbrBackground = NULL;
    if (!RegisterClassEx (&wincl)) return FALSE;

#if 0
    /* ---------------------------------------------------------------------- */
    /* Edit control                                                           */
    /* ---------------------------------------------------------------------- */
    wincl.lpszClassName = "ExGUIInfo";
    wincl.lpfnWndProc = infoWindowProcedure;
    wincl.cbWndExtra = 0;
    wincl.hbrBackground = (HBRUSH) CreateSolidBrush(RGB(255, 255, 255));
    if (!RegisterClassEx (&wincl)) return FALSE;
#endif
    /* All classes were registered successfully: */
    return TRUE;
}

