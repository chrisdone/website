#include <windows.h>

#define TAB_TOP     10
#define TAB_LEFT    10
#define TAB_WIDTH   335
#define TAB_HEIGHT  34
#define ID_TABMENU 1
#define TAB_COUNT 4

#define FRAME_TOP     60
#define FRAME_LEFT    10
#define FRAME_WIDTH   160
#define FRAME_HEIGHT  210
#define ID_FRAME 5

#define CONTACTS_TOP     290
#define CONTACTS_LEFT    10
#define CONTACTS_WIDTH   160
#define CONTACTS_HEIGHT  270
#define ID_CONTACTS 6
#define ID_CONTACTS_FRAME 14

#define LIST_TOP     25
#define LIST_LEFT    1
#define LIST_WIDTH   158
#define LIST_HEIGHT  240
#define ID_LIST 6
#define CONTACT_COUNT 9

#define BUTTON_TOP     60
#define BUTTON_LEFT    190
#define BUTTON_WIDTH   100
#define BUTTON_HEIGHT  34
#define ID_BUTTON 2

#define OPTIONS_TOP     15
#define OPTIONS_LEFT    370
#define OPTIONS_WIDTH   65
#define OPTIONS_HEIGHT  24
#define ID_LINK 3

#define HELP_TOP     15
#define HELP_LEFT    450
#define HELP_WIDTH   50
#define HELP_HEIGHT  24
#define ID_HELP 7

#define SEARCH_TOP     60
#define SEARCH_LEFT    190
#define SEARCH_WIDTH   450
#define SEARCH_HEIGHT  500

#define WINDOW_WIDTH    660
#define WINDOW_HEIGHT   600

#define ID_SEARCHBOX 12

#define ID_RESULTS_FRAME 13

LRESULT CALLBACK windowProcedure (HWND, UINT, WPARAM, LPARAM);

int WINAPI WinMain (HINSTANCE instance, HINSTANCE prevInst, LPSTR arguments, int toShow)
{
    HWND windowHandle;
    MSG messages;
    WNDCLASSEX wincl;
    if (!LoadLibrary ("exgui.dll")) return FALSE;

    windowHandle = CreateWindowEx (
    WS_CLIPCHILDREN,
    "ExGUIWindow",
    "SLSK",
    WS_POPUP,
    CW_USEDEFAULT,
    CW_USEDEFAULT,
    WINDOW_WIDTH,
    WINDOW_HEIGHT,
    HWND_DESKTOP,
    NULL,
    instance,
    NULL);

    SendMessage (windowHandle, WM_USER, (WPARAM)windowProcedure, (LPARAM)0);

    ShowWindow (windowHandle, toShow);

    while (GetMessage (&messages, NULL, 0, 0))
    {
        TranslateMessage(&messages);
        DispatchMessage(&messages);
    }

    return messages.wParam;
}

LRESULT CALLBACK windowProcedure (HWND windowHandle, UINT message, WPARAM wParam, LPARAM lParam)
{
    HWND tabMenu;
    HWND sampleButton;
    char *tabCaption[TAB_COUNT];
    int tabIndex;
    int *selectedTabs;
    int tabsSelected;
    HWND tabsHandle;
    HWND frameHandle;
    HWND listHandle;
    HWND contactsHandle;
    char *contactList[CONTACT_COUNT];
    int listIndex;
    HWND staticHandle;
    char searchText[512];
    RECT windowRect;
    MINMAXINFO *maxInfo;

    tabCaption[0] = "Shared";
    tabCaption[1] = "Search";
    tabCaption[2] = "Transfers";
    tabCaption[3] = "Contact";

    contactList[0] = "Chris";
    contactList[1] = "Dave";
    contactList[2] = "John";
    contactList[3] = "penis48";
    contactList[4] = "penis48";
    contactList[5] = "hyriand";
    contactList[6] = "dmh_";
    contactList[7] = "Mary";
    contactList[8] = "rillmo";

    switch (message)
    {
        case WM_COMMAND:
        {
            switch (LOWORD(wParam))
            {
                case ID_BUTTON:
                {

                    break;
                }
                case ID_LINK:
                {
                    MessageBox (windowHandle, "You clicked the link!", "Event.", 0);
                    break;
                }
                case ID_TABMENU:
                {
                    switch(HIWORD(wParam))
                    {
                        case LBN_SELCHANGE:
                        {
                            tabsHandle = GetDlgItem(windowHandle, ID_TABMENU);
                            tabsSelected = SendMessage(tabsHandle, LB_GETSELCOUNT, 0, 0);

                            selectedTabs = malloc(sizeof(int) * tabsSelected);
                            SendMessage(tabsHandle, LB_GETSELITEMS, (WPARAM)tabsSelected, (LPARAM)selectedTabs);

                            for (tabIndex = 0; tabIndex < tabsSelected; tabIndex ++)
                            {
                                MessageBox (windowHandle, tabCaption[selectedTabs[tabIndex]], "Selected tab item.", 0);
                            }

                            free (selectedTabs);
                            break;
                        }
                    }
                    break;
                }
            }
            break;
        }
        case WM_CREATE:
        {
            tabMenu = CreateWindowEx (
            0,
            "ExGUITabMenu",
            NULL,
            WS_CHILD + WS_VISIBLE,
            TAB_LEFT,
            TAB_TOP,
            TAB_WIDTH,
            TAB_HEIGHT,
            windowHandle,
            (HMENU)ID_TABMENU,
            GetModuleHandle (0),
            NULL);

            for (tabIndex = 0; tabIndex < TAB_COUNT; tabIndex ++)
            {
                SendMessage(tabMenu, (UINT)LB_ADDSTRING, (WPARAM)0, (LPARAM)tabCaption[tabIndex]);
            }

            frameHandle = CreateWindowEx (
            0,
            "ExGUIFrame",
            "Search query",
            WS_CHILD + WS_VISIBLE,
            FRAME_LEFT,
            FRAME_TOP,
            FRAME_WIDTH,
            FRAME_HEIGHT,
            windowHandle,
            (HMENU)ID_FRAME,
            GetModuleHandle (0),
            NULL);

            staticHandle = CreateWindowEx (
            0,
            "ExGUIStatic",
            "Search for:",
            WS_CHILD + WS_VISIBLE,
            10,
            30,
            70,
            20,
            frameHandle,
            (HMENU)ID_FRAME,
            GetModuleHandle (0),
            NULL);

            CreateWindowEx (
            0,
            "ExGUIEdit",
            "[empty]",
            WS_CHILD + WS_VISIBLE,
            10,
            55,
            115,
            20,
            frameHandle,
            (HMENU)ID_SEARCHBOX,
            GetModuleHandle (0),
            NULL);

            CreateWindowEx (
            0,
            "ExGUIButton",
            "Go",
            WS_CHILD + WS_VISIBLE,
            10,
            85,
            40,
            34,
            frameHandle,
            (HMENU)ID_BUTTON,
            GetModuleHandle (0),
            NULL);

            CreateWindowEx (
            0,
            "ExGUILink",
            "Options",
            WS_CHILD + WS_VISIBLE,
            OPTIONS_LEFT,
            OPTIONS_TOP,
            OPTIONS_WIDTH,
            OPTIONS_HEIGHT,
            windowHandle,
            (HMENU)ID_LINK,
            GetModuleHandle (0),
            NULL);

            CreateWindowEx (
            0,
            "ExGUILink",
            "Help!",
            WS_CHILD + WS_VISIBLE,
            HELP_LEFT,
            HELP_TOP,
            HELP_WIDTH,
            HELP_HEIGHT,
            windowHandle,
            (HMENU)ID_LINK,
            GetModuleHandle (0),
            NULL);

            frameHandle = CreateWindowEx (
            0,
            "ExGUIFrame",
            "Contacts",
            WS_CHILD + WS_VISIBLE,
            CONTACTS_LEFT,
            CONTACTS_TOP,
            CONTACTS_WIDTH,
            CONTACTS_HEIGHT,
            windowHandle,
            (HMENU)ID_CONTACTS_FRAME,
            GetModuleHandle (0),
            NULL);

            listHandle = CreateWindowEx (
            0,
            "ExGUIList",
            "No contacts",
            WS_CHILD + WS_VISIBLE,
            LIST_LEFT,
            LIST_TOP,
            LIST_WIDTH,
            LIST_HEIGHT,
            frameHandle,
            (HMENU)ID_LIST,
            GetModuleHandle (0),
            NULL);

            for (listIndex = 0; listIndex < CONTACT_COUNT; listIndex ++)
            {
                SendMessage(listHandle, (UINT)LB_ADDSTRING, (WPARAM)0, (LPARAM)contactList[listIndex]);
            }

            frameHandle = CreateWindowEx (
            0,
            "ExGUIFrame",
            "Search results",
            WS_CHILD + WS_VISIBLE,
            SEARCH_LEFT,
            SEARCH_TOP,
            SEARCH_WIDTH,
            SEARCH_HEIGHT,
            windowHandle,
            (HMENU)ID_RESULTS_FRAME,
            GetModuleHandle (0),
            NULL);

            SendMessage (windowHandle, WM_SIZE, 0, 0);

            break;
        }
        case WM_GETMINMAXINFO:
        {
            maxInfo = (MINMAXINFO *)lParam;
            maxInfo->ptMinTrackSize.y = WINDOW_HEIGHT;
            maxInfo->ptMinTrackSize.x = WINDOW_WIDTH;
            break;
        }
        case WM_SIZE:
        {
            GetWindowRect(windowHandle, &windowRect);
            frameHandle = GetDlgItem (windowHandle, ID_RESULTS_FRAME);
            contactsHandle = GetDlgItem (windowHandle, ID_CONTACTS_FRAME);
            SetWindowPos (frameHandle, NULL,
            SEARCH_LEFT, SEARCH_TOP,
            ((windowRect.right - windowRect.left) - SEARCH_LEFT) - 20,
            ((windowRect.bottom - windowRect.top) - SEARCH_TOP) - 20,
            SWP_NOMOVE);
            SetWindowPos (contactsHandle, NULL,
            CONTACTS_LEFT, CONTACTS_TOP,
            CONTACTS_WIDTH,
            ((windowRect.bottom - windowRect.top) - CONTACTS_TOP) - 20,
            SWP_NOMOVE);
            break;
        }
        case WM_DESTROY:
            PostQuitMessage (0);
            break;
        default: return DefWindowProc (windowHandle, message, wParam, lParam);
    }

    return 0;
}
